<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01//EN" "http://www.w3.org/TR/html4/strict.dtd">
<HTML>
<HEAD>
    <META http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <META http-equiv="X-UA-Compatible" content="IE=8">
    <TITLE>bcl_602169485.htm</TITLE>
    <!-- #include virtual="/convert-pdf-to-html/includes/pdf-to-word-head-tag.htm" -->
    <META name="generator" content="BCL easyConverter SDK 5.0.08">
    <STYLE type="text/css">


        #page_1 {position:relative; overflow: hidden;margin: 62px 0px 13px 0px;padding: 0px;border: none;width: 793px;}
        #page_1 #id_1 {border:none;margin: 19px 0px 0px 0px;padding: 0px;border:none;width: 793px;overflow: hidden;}
        #page_1 #id_2 {border:none;margin: 40px 0px 0px 679px;padding: 0px;border:none;width: 114px;overflow: hidden;}

        #page_1 #p1dimg1 {position:absolute;top:0px;left:22px;z-index:-1;width:757px;height:930px;}
        #page_1 #p1dimg1 #p1img1 {width:757px;height:930px;}




        #page_2 {position:relative; overflow: hidden;margin: 72px 0px 13px 11px;padding: 0px;border: none;width: 782px;}
        #page_2 #id_1 {border:none;margin: 11px 0px 0px 0px;padding: 0px;border:none;width: 782px;overflow: hidden;}
        #page_2 #id_2 {border:none;margin: 40px 0px 0px 668px;padding: 0px;border:none;width: 114px;overflow: hidden;}

        #page_2 #p2dimg1 {position:absolute;top:0px;left:1px;z-index:-1;width:767px;height:920px;}
        #page_2 #p2dimg1 #p2img1 {width:767px;height:920px;}



        .page-break {
            page-break-after: always;
        }
        #page_3 {position:relative; overflow: hidden;margin: 72px 0px 13px 11px;padding: 0px;border: none;width: 782px;}
        #page_3 #id_1 {border:none;margin: 11px 0px 0px 0px;padding: 0px;border:none;width: 782px;overflow: hidden;}
        #page_3 #id_2 {border:none;margin: 40px 0px 0px 668px;padding: 0px;border:none;width: 114px;overflow: hidden;}

        #page_3 #p3dimg1 {position:absolute;top:0px;left:1px;z-index:-1;width:767px;height:920px;}
        #page_3 #p3dimg1 #p3img1 {width:767px;height:920px;}




        .dclr {clear:both;float:none;height:1px;margin:0px;padding:0px;overflow:hidden;}

        .ft0{font: bold 13px 'Courier New';line-height: 16px;}
        .ft1{font: 11px 'Courier New';line-height: 14px;}
        .ft2{font: 16px 'Courier New';line-height: 18px;}
        .ft3{font: 9px 'Courier New';line-height: 12px;}
        .ft4{font: 10px 'Courier New';line-height: 12px;}
        .ft5{font: 11px 'Courier New';margin-left: 6px;line-height: 19px;}
        .ft6{font: 11px 'Courier New';line-height: 19px;}
        .ft7{font: 10px 'Courier New';margin-left: 6px;line-height: 15px;}
        .ft8{font: 10px 'Courier New';line-height: 15px;}
        .ft9{font: 11px 'Courier New';margin-left: 6px;line-height: 15px;}
        .ft10{font: 11px 'Courier New';line-height: 15px;}
        .ft11{font: 11px 'Courier New';margin-left: 6px;line-height: 14px;}
        .ft12{font: 16px 'Courier New';color: #ff0000;line-height: 18px;}
        .ft13{font: 1px 'Courier New';line-height: 1px;}
        .ft14{font: bold 12px 'Courier New';line-height: 16px;}
        .ft15{font: bold 15px 'Courier New';line-height: 17px;}

        .p0{text-align: left;padding-left: 22px;margin-top: 0px;margin-bottom: 0px;}
        .p1{text-align: left;padding-left: 22px;margin-top: 7px;margin-bottom: 0px;}
        .p2{text-align: left;padding-left: 22px;margin-top: 6px;margin-bottom: 0px;}
        .p3{text-align: left;padding-left: 325px;margin-top: 47px;margin-bottom: 0px;}
        .p4{text-align: left;margin-top: 0px;margin-bottom: 0px;white-space: nowrap;}
        .p5{text-align: left;padding-left: 46px;margin-top: 25px;margin-bottom: 0px;}
        .p6{text-align: left;padding-left: 45px;padding-right: 523px;margin-top: 5px;margin-bottom: 0px;text-indent: 1px;}
        .p7{text-align: left;padding-left: 45px;margin-top: 6px;margin-bottom: 0px;}
        .p8{text-align: left;padding-left: 45px;margin-top: 18px;margin-bottom: 0px;}
        .p9{text-align: left;padding-left: 45px;margin-top: 22px;margin-bottom: 0px;}
        .p10{text-align: left;padding-left: 71px;margin-top: 78px;margin-bottom: 0px;}
        .p11{text-align: left;padding-left: 71px;margin-top: 18px;margin-bottom: 0px;}
        .p12{text-align: left;padding-left: 71px;margin-top: 17px;margin-bottom: 0px;}
        .p13{text-align: left;padding-left: 88px;padding-right: 253px;margin-top: 4px;margin-bottom: 0px;text-indent: -17px;}
        .p14{text-align: left;padding-left: 88px;padding-right: 275px;margin-top: 4px;margin-bottom: 0px;text-indent: -17px;}
        .p15{text-align: left;padding-left: 88px;padding-right: 236px;margin-top: 5px;margin-bottom: 0px;text-indent: -17px;}
        .p16{text-align: left;padding-left: 88px;padding-right: 281px;margin-top: 5px;margin-bottom: 0px;text-indent: -17px;}
        .p17{text-align: left;padding-left: 82px;padding-right: 275px;margin-top: 6px;margin-bottom: 0px;text-indent: -11px;}
        .p18{text-align: right;padding-right: 78px;margin-top: 157px;margin-bottom: 0px;}
        .p19{text-align: left;padding-left: 114px;margin-top: 24px;margin-bottom: 0px;}
        .p20{text-align: left;margin-top: 0px;margin-bottom: 0px;}
        .p21{text-align: left;padding-left: 1px;margin-top: 0px;margin-bottom: 0px;}
        .p22{text-align: left;padding-left: 1px;margin-top: 6px;margin-bottom: 0px;}
        .p23{text-align: left;padding-left: 1px;margin-top: 7px;margin-bottom: 0px;}
        .p24{text-align: left;padding-left: 5px;margin-top: 0px;margin-bottom: 0px;white-space: nowrap;}
        .p25{text-align: left;padding-left: 13px;margin-top: 0px;margin-bottom: 0px;white-space: nowrap;}
        .p26{text-align: left;padding-left: 53px;margin-top: 0px;margin-bottom: 0px;white-space: nowrap;}
        .p27{text-align: left;padding-left: 26px;margin-top: 0px;margin-bottom: 0px;white-space: nowrap;}
        .p28{text-align: left;padding-left: 3px;margin-top: 0px;margin-bottom: 0px;white-space: nowrap;}
        .p29{text-align: left;padding-left: 9px;margin-top: 0px;margin-bottom: 0px;white-space: nowrap;}
        .p30{text-align: left;padding-left: 12px;margin-top: 0px;margin-bottom: 0px;white-space: nowrap;}
        .p31{text-align: left;padding-left: 16px;margin-top: 0px;margin-bottom: 0px;white-space: nowrap;}
        .p32{text-align: center;margin-top: 0px;margin-bottom: 0px;white-space: nowrap;}
        .p33{text-align: right;padding-right: 16px;margin-top: 0px;margin-bottom: 0px;white-space: nowrap;}
        .p34{text-align: center;padding-right: 2px;margin-top: 0px;margin-bottom: 0px;white-space: nowrap;}
        .p35{text-align: right;padding-right: 19px;margin-top: 0px;margin-bottom: 0px;white-space: nowrap;}
        .p36{text-align: right;padding-right: 11px;margin-top: 0px;margin-bottom: 0px;white-space: nowrap;}
        .p37{text-align: right;padding-right: 5px;margin-top: 0px;margin-bottom: 0px;white-space: nowrap;}
        .p38{text-align: left;padding-left: 512px;margin-top: 72px;margin-bottom: 0px;}
        .p39{text-align: left;padding-left: 103px;margin-top: 24px;margin-bottom: 0px;}
        .p40{text-align: left;padding-left: 14px;margin-top: 0px;margin-bottom: 0px;white-space: nowrap;}
        .p41{text-align: right;padding-right: 6px;margin-top: 0px;margin-bottom: 0px;white-space: nowrap;}
        .p42{text-align: right;padding-right: 12px;margin-top: 0px;margin-bottom: 0px;white-space: nowrap;}
        .p43{text-align: left;padding-left: 512px;margin-top: 522px;margin-bottom: 0px;}

        .td0{padding: 0px;margin: 0px;width: 420px;vertical-align: bottom;}
        .td1{padding: 0px;margin: 0px;width: 133px;vertical-align: bottom;}
        .td2{padding: 0px;margin: 0px;width: 109px;vertical-align: bottom;}
        .td3{border-left: #000000 1px solid;border-right: #000000 1px solid;border-top: #000000 1px solid;padding: 0px;margin: 0px;width: 26px;vertical-align: bottom;}
        .td4{border-right: #000000 1px solid;border-top: #000000 1px solid;padding: 0px;margin: 0px;width: 93px;vertical-align: bottom;}
        .td5{border-right: #000000 1px solid;border-top: #000000 1px solid;padding: 0px;margin: 0px;width: 194px;vertical-align: bottom;}
        .td6{border-right: #000000 1px solid;border-top: #000000 1px solid;padding: 0px;margin: 0px;width: 101px;vertical-align: bottom;}
        .td7{border-right: #000000 1px solid;border-top: #000000 1px solid;padding: 0px;margin: 0px;width: 79px;vertical-align: bottom;}
        .td8{border-right: #000000 1px solid;border-top: #000000 1px solid;padding: 0px;margin: 0px;width: 64px;vertical-align: bottom;}
        .td9{border-right: #000000 1px solid;border-top: #000000 1px solid;padding: 0px;margin: 0px;width: 45px;vertical-align: bottom;}
        .td10{border-right: #000000 1px solid;border-top: #000000 1px solid;padding: 0px;margin: 0px;width: 40px;vertical-align: bottom;}
        .td11{border-right: #000000 1px solid;border-top: #000000 1px solid;padding: 0px;margin: 0px;width: 48px;vertical-align: bottom;}
        .td12{border-right: #000000 1px solid;border-top: #000000 1px solid;padding: 0px;margin: 0px;width: 72px;vertical-align: bottom;}
        .td13{border-left: #000000 1px solid;border-right: #000000 1px solid;border-bottom: #000000 1px solid;padding: 0px;margin: 0px;width: 26px;vertical-align: bottom;}
        .td14{border-right: #000000 1px solid;border-bottom: #000000 1px solid;padding: 0px;margin: 0px;width: 93px;vertical-align: bottom;}
        .td15{border-right: #000000 1px solid;border-bottom: #000000 1px solid;padding: 0px;margin: 0px;width: 194px;vertical-align: bottom;}
        .td16{border-right: #000000 1px solid;border-bottom: #000000 1px solid;padding: 0px;margin: 0px;width: 101px;vertical-align: bottom;}
        .td17{border-right: #000000 1px solid;border-bottom: #000000 1px solid;padding: 0px;margin: 0px;width: 79px;vertical-align: bottom;}
        .td18{border-right: #000000 1px solid;border-bottom: #000000 1px solid;padding: 0px;margin: 0px;width: 64px;vertical-align: bottom;}
        .td19{border-right: #000000 1px solid;border-bottom: #000000 1px solid;padding: 0px;margin: 0px;width: 45px;vertical-align: bottom;}
        .td20{border-right: #000000 1px solid;border-bottom: #000000 1px solid;padding: 0px;margin: 0px;width: 40px;vertical-align: bottom;}
        .td21{border-right: #000000 1px solid;border-bottom: #000000 1px solid;padding: 0px;margin: 0px;width: 48px;vertical-align: bottom;}
        .td22{border-right: #000000 1px solid;border-bottom: #000000 1px solid;padding: 0px;margin: 0px;width: 72px;vertical-align: bottom;}
        .td23{border-left: #000000 1px solid;border-right: #000000 1px solid;padding: 0px;margin: 0px;width: 26px;vertical-align: bottom;}
        .td24{border-right: #000000 1px solid;padding: 0px;margin: 0px;width: 93px;vertical-align: bottom;}
        .td25{border-right: #000000 1px solid;padding: 0px;margin: 0px;width: 194px;vertical-align: bottom;}
        .td26{border-right: #000000 1px solid;padding: 0px;margin: 0px;width: 101px;vertical-align: bottom;}
        .td27{border-right: #000000 1px solid;padding: 0px;margin: 0px;width: 79px;vertical-align: bottom;}
        .td28{border-right: #000000 1px solid;padding: 0px;margin: 0px;width: 64px;vertical-align: bottom;}
        .td29{border-right: #000000 1px solid;padding: 0px;margin: 0px;width: 45px;vertical-align: bottom;}
        .td30{border-right: #000000 1px solid;padding: 0px;margin: 0px;width: 40px;vertical-align: bottom;}
        .td31{border-right: #000000 1px solid;padding: 0px;margin: 0px;width: 48px;vertical-align: bottom;}
        .td32{border-right: #000000 1px solid;padding: 0px;margin: 0px;width: 72px;vertical-align: bottom;}
        .td33{border-right: #000000 1px solid;border-top: #000000 1px solid;padding: 0px;margin: 0px;width: 46px;vertical-align: bottom;}
        .td34{border-right: #000000 1px solid;border-top: #000000 1px solid;padding: 0px;margin: 0px;width: 39px;vertical-align: bottom;}
        .td35{border-right: #000000 1px solid;border-top: #000000 1px solid;padding: 0px;margin: 0px;width: 50px;vertical-align: bottom;}
        .td36{border-right: #000000 1px solid;border-top: #000000 1px solid;padding: 0px;margin: 0px;width: 70px;vertical-align: bottom;}
        .td37{border-right: #000000 1px solid;border-bottom: #000000 1px solid;padding: 0px;margin: 0px;width: 46px;vertical-align: bottom;}
        .td38{border-right: #000000 1px solid;border-bottom: #000000 1px solid;padding: 0px;margin: 0px;width: 39px;vertical-align: bottom;}
        .td39{border-right: #000000 1px solid;border-bottom: #000000 1px solid;padding: 0px;margin: 0px;width: 50px;vertical-align: bottom;}
        .td40{border-right: #000000 1px solid;border-bottom: #000000 1px solid;padding: 0px;margin: 0px;width: 70px;vertical-align: bottom;}
        .td41{border-right: #000000 1px solid;padding: 0px;margin: 0px;width: 46px;vertical-align: bottom;}
        .td42{border-right: #000000 1px solid;padding: 0px;margin: 0px;width: 39px;vertical-align: bottom;}
        .td43{border-right: #000000 1px solid;padding: 0px;margin: 0px;width: 50px;vertical-align: bottom;}
        .td44{border-right: #000000 1px solid;padding: 0px;margin: 0px;width: 70px;vertical-align: bottom;}

        .tr0{height: 14px;}
        .tr1{height: 19px;}
        .tr2{height: 16px;}
        .tr3{height: 18px;}
        .tr4{height: 15px;}
        .tr5{height: 17px;}

        .t0{width: 662px;margin-left: 46px;margin-top: 23px;font: 11px 'Courier New';}
        .t1{width: 772px;margin-top: 21px;font: 11px 'Courier New';}
        table, th, td {
            font-size:10px
        }
        table {
            font-family: arial, sans-serif;
            border-collapse: collapse;
            width: 100%;
        }

        td, th {
            border: 1px solid #dddddd;
            text-align: left;
            padding: 8px;
        }
        .header,
        .footer {
            width: 100%;
            text-align: center;
            position: fixed;
        }
        .header {
            top: 0px;
        }
        .footer {
            bottom: 0px;
        }
        .pagenum:before {
            content: counter(page);
        }

    </STYLE>
</HEAD>

<BODY>


<!-- #include virtual="/convert-pdf-to-html/includes/pdf-to-word-body-tag-02242014.htm" -->
<DIV id="page_1">
    <DIV id="p1dimg1">
        <IMG style="margin-left: 69%;width: 223px;" src="data:image/jpg;base64,iVBORw0KGgoAAAANSUhEUgAAAMoAAABUCAYAAADDCaibAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAACQYSURBVHhe7V0HY1Tltn0/5FoAk0x6QBEFC1wloQQChC4IitIEEZAiKNKkCEqVlt5oaZAGhBKpoSOEXkNCSJ1k0nvWW/s7k5ig0cl78B5yv1zPTcicmTmzv7322nvt/Z38F/h16Pg9RMTdQMTeazyu6kPbQPtAMx8QjPyX/N8n85PhNjAcnXzD4TEojEeoPrQNtA9YfaAJKGNnJsC5dwBcvLbCtbc/3PizPrQNtA8YPtAElI8IFIc+gXDiLx17B+lD20D7QDMfaALKqJlxMPUOJKsE0kAEjIBGH9oG2geUD2igaEfQwcAGH9BAscFImll1dqGBooGiGcUGH9BAscFImlE0o2igaKBoRrHBBzRQbDCSZhTNKBooGiiaUWzwAQ0UG4ykGUUzigaKBopmFBt8QAPFBiNpRtGMooGigaIZxQYf0ECxwUiaUTSjaKBooGhGscEHNFBsMJJmFM0oGigaKJpRbPABDRQbjKQZRTOKBooGimYUG3xAA8UGI2lG0YyigaKBohnFBh/QQLHBSJpRNKNooGigaEaxwQc0UGwwkmYUzSgaKBoomlFs8AENFBuMpBlFM8ozB4rcVE9uqOfcx5832NsKRzqmLcd/inPKDQedehk2MvUNYHTnbW17haLboBB8+t0+dBu5U92909UzFPZ83NTLn//m4cnjL2xp4nPkXGVrPk++q7XoE6SeZ+obCDu+13+Knf+3n/OZA0UW2cSFdegTDFOfCAJGQPPXx//2Q/1Tnu9AR7UT5+9L5+0dDDfPQHiPi8JS/5MI3nMZ27anYtnGw5i//iDGzzyCTrwvtAuf48iA4yBO3yv8L23pIqAgWCRIOfcVgMktc2n7Xryfbq8ggk8zha2+8syB4kiQmLhgbw0NxpzliZi+POVvj34TY/4jIp2bdzC6j9qJYV9GY9HGMwiPv4rEo/cRtPMsdgenIuTHOMR964fk3hNx2vFNLOkykUGHzk9weU+KwKxlSX9py69+OIJpSw9h3DdJ+HhWEkZ9nYQhU+PQ89MoeAwINu41rQ+bbPB/AhR7ssqwr2JgKa1BTX0D6urqUcvv/K/pqKurQ01DLapqarE68LxNF///ssj8LE6M0I48VITuFcxDIncAI7WkNUEMDC3TS5NiAd74XKU6cgTjvY+2Y+G6X7Er6RrOXMvFgV+vYZ9fAg7N3YDjn3yDK31HIM3xbeS86oyClx2R184BYW6D4dprG8ESgJVBJ1FeRXvSbrV1tX+wZ21dA6pp5+p62rW+BnX19Ty/HNn5Fly4monAqN8wfFoCr8tIy4T5/1/s+Q8B6jMHiro7PvPh15lzj52eiAVrDuDmvTyCpU7d+Ljxq6amHmEJVzFxzl78e9SO53fRevvRuSSdkVRyG1Ogbfx8QYzOUn9tgVs/P7w7Yhd6fxqNfhPi8P6IcLiTARy8QhQb2BNcH3wchpRTmTh7JQt7d55A3MTluOjpi/uduuO+XWcUEhjmV01NR8Er9gSMCQecPPG250YySjDeH70Dn329F1vJPgWWMtTW1rSw54KfU8kgCRi/4CDWh59HRo4FddW1qCdwGhiQamuqcSu9AJ99d0CBxbl3yPNr8+cATP8HQBF638bCcTMcCBjHPqFYtoXRsLyqxcJeuZ1HJ9oMR+/Govb5TAsc+Vlc6FSuvfzw6dy9WLHtHOb/dAQbwi4h5uA9HLvwCFfvZeF82gOk3c7Gg6wS3M60YG3oKXQZEYrOA8Jx5VYGDsenIr7/p7jbviOKyBo5rzgh/xVHFL3SAWb+3Bwo+QRJ7qv2OGPfFUO6/6BqFHvvrTB5h8CjXxAOnU9HPZm4+degL6J53mbanueR7XoMDcG1e4/JLDVk8XrwPzRUNyD1SibeGx3Besco8vXx5zZ45kBR0YqqjgsXwlFF40BMWpCMPLOlxcLGHUyDfb8wVXyqcyVdaTyUWiMH0wP1syhoRsrQlDZI6mD9cxUqnVD/bvyd9bWaP84USV7PJK+l3sd4/cZD/V69h6RZcq5RCEsB3mXwDnw8Ow7rgi9gw+YT2Bl+Agk7juLI9l+x3y8JUat2IGrpduxeFM4jDJHLd+FseBJ2hR/BsjV7EffNSgKkKwoIjDyCIP/VDrC8bEIBwVDwigPyXnntCaA4IbedHW506IRJXeeQzcSWwXRuFuZe2xCedP0PjOL1yS7rZwlWfyBKAtSwadEoY7pW18B0jP9rILtkZVswbsF+CgrbjL+No9JEQyGTNFLZUaWZtIMcTTYXpe53G6vfN9nXqsw12dPqfNb0Ts5TRzObq3W1/tkRYz1+P4zHRBSS95PXlseMNTFSYOM6jH8L4K3nPUXgP3Og/FmE+nz+AeQVlLUASmzyTXQeFo7Rs/fQCVl8Nh2JGD0rnr9Pwnsfb1dSqqhovT7fiTHWc+SxMbP2YsDUaKo7Ieg+ejumLk7G0k0nsGxzKhZuSMUU/nvg5FhG4ED0/CQSH89JwCi+bv+pkRgyPY7P39fiPUd+HYdBU2IxjH83ZszsePh+uQdvDIpA155rsclnPhLHLcSxUTNwceRUpPl8ggvv+OC8Sw+kvdYZDzp40Okdmo68dib+viP8evTD6v7DsdblDeS+bE+A/J5eNWeQJ38ueskR2e074PErLljYWQp6grivnwpA4hQhsWmoqa1uYc8uQ8Kb2EFURglA7zGlvf+oqOm8hoYGFBSW4KslhxkA/FSAsidjiqO+RQb6fF4yvltznBnAKWXL6csPMZ2MhCtZTJzSQTmtEUDEgT8cvQuTFyVj4cZTtPsZChQnMWVJMnqO2Q1XpqeOrK86+QZzLRN4cE3nxOHjuVzfOYkUG/h9diIGT4pBx0FB1sd53hyKEBQiRs+K45EI9wEEKxU8r89246tlR7B0ayqWb0rFd+uOY+LCA/Dh890UUJ4uQz43QIk5cAMjZ8YiPSsPmY95MNLJkZFdiMysXDx8nI/Zq04aUYxOsiXyHO5nFiGTaU1GVhEy+JzEY7cxfXEizl/PRkZuMa7cycPte4WwlJch31yAOw8LMOH7ZKwMOM3XzkHGIzPupBfifoa8R0HTe8r7PuTr3s0owoPMfDzKzsORM7fQZ+IudO+5EZkd3JH9iol1gwMd2AH5Hej0L3dA4b+YOpEZCl8iMzQDivklZ+SSKaJNLljs7ITFLq64S/A8WYu0BpbCl+R9yDJ8jy0dh8HVyyoKqAj+90BxZJoorNDjox14nFPeAigPswswem6SAapeW+HG+mfc/HiknL+HRzmFyMopxqnzmbh+z4y8ohLcup+Dbbsv4X2KEcJsdgTYWwNCsWj9MVyk3bPyi7guFpw4m467mWbkMHO4dC0TC/n4GwPD4EWgpT/meom9udaPCNzMrEL+28y1zkN8SgZ8x+/gOWZkymOPuBaP5fFc/q4QXh8FExSHmdbmIeuxBVdv5OPuwyJYysqQm2/GjfRc+ErayRryaaaRzxVQXPruwtCvYpFyKYvpQX3TcfdhIWYsOYKO/UXSZCrnFYq3B4Zg3roDKK2iUlZdifCEm5i34iCKSi0oKirD4vWH8Tr/cOubvgH4nobNN5dQHarBAtYTW3deR0NdJWpZ1B6lQyzakILDZzKa3i+vqBw/BZ/CtqjzKC6tQENtPe49zMPQ6fF8b3/c7fCWSpMKX3ZT4Mh/1Yk1hh3TqA782R55L//OJgKYrA5OKGjXDskEyg8uHTHPpTMutXMkeOxbpFitAUVe18zXyWOqFuvhjW6e6xn5JaWVAvzvgSI1iqnXFkxYeJjM83ttKIySknoPbw6R9Ixpcd9wfMFAk8FAUceap6i0msErEu6+ZFLaMYQAqaMNa2qqEJdyEx19dsCdx89BqTyXduJjZ9Ky8eHYMLJCBD4YHoFjZ7L5nEqUlJZjbTADnXcQvCfsQkT8FapwVXxOA1W5Ktx8kIcvyUZdfMPgwHWe+G0ybjGwNdRV8bxq7E25jo/m7sOMpQdRwX9nEDRfLN6Hzr4heMs3FD/7nUBpaSWqG6oxihmCKIsvJFD2JN8yOshkjNmk+6LiUio0lDdr6+AfdQUuSgiQyPh7sSU57aHTmchk5BvPPPu36yxWKYkepdO/zijn5CU1RRDc+4dgfdhZVNLA834+TgD8hqrKGmzcfo5UznRg4E7Vw2j8epxbiiEErDjPSKZ0OQTe/cxcOk0i040gRLv0ZXRnbUGW+KuUqfGx3FdfI8uYcPw1Ryx38iCjdEKCgzOBZhtQhK3MBJa852mH9+D1wSraYhuvj5+xFaB0Hb4Dbt7h6My/8PzOSKaiC+KQk1uGOqpjtbW1KCwux5krj9CHTqvqD6ZGvcfuJKMXol7k+5o6TF+TYkwNeFPZk/fjOZdu5PBx1jg1NfDbfQFTlh5AIUFSX1+L0uoK9J+wj9dFBZB2MlERfJfqXHZBqZKwy2sqMGXhfqZg/vho+h6kP+J7sU6Sw293GtMzKoPeW/g+wZi58gge5xUhnVnDl+y/OfG9uzBtu/3QQmBVI5IZiJs3/UHVvcEqpdux/wb9pRYfzYpW57/wQJm8mDVMfrECSmV1NdaHsq+iir+WWr8DI+rmiAu4wRRr1qojyC2Q5zTgFJWnrqx3FP1y0WSxxzL/FYqfv/okdu2/iktX6STMnSXffZ3OFBF3rQVQhn61h6mFAbZ1oafx8FEu5dZ4/tXkIHz/1gSyB1mDEd42oJB9/uWAyx0c8bOTG5Y4d0K4SVjIthpF2EsK/AIy1Z32b2Bo98XKFmr8pRWg+Eeex6ZwNjH3XsHxCw9QWlFNNqlhKlmA2APXaa+jeGNIEF+Dh/SA+D0m+SpZlo5LoOQWVMLDZzN/H6YaxlIPOdAhf9h0jMGIMjOBUsHXvHNfgCWycz1O/5alzpPXEtuLOufmE4bElBsECmVpKm730s14nyAeNGkv7qbnU4WjVM3nbwg9p8DoxPGdyfP24erNHAa8TAyYLOqdnxIXhlPuzi8qJkhrsefgdQUOVeCrwn8bpjOjyLdYMGZGPJ8jQeTpqXjPTerVnFEms/DOyyulERuYVglQLnIBmHZxQZt/eEnDVvudweUb2QTAKRamZUr6LCyuwEY6yZvDqKIpI/qjG3+Wgm/QxETmy0fYzzkC934hsPMOIFBCsT0urRlQyqgQ8Y+/EkTCSB8y0obEXEa/SVEqUg7usYQplt0fZNzWQJNNUBWxznjApuEvzm5Y6tQJGxwdkdHO2UagOaFi7rfI/3wS8jt2wfh358LDM4TXQsdqBShmSwUKzOUoK680HJsgEaBk5RXjwPG7mPfTr3ib6p2Jzu/sJQ3QcJQx1ZL0tI5R+fTFB+qzS2FvIpO7kgXsaI8RFDekZ1NLBxdbN4KkgUDZGnFRzauJYzvI3JrI00yn1wSkqr5ZLZlD0q2vfzyEgV/sIVAktWKKzdfayGAo2cTkeUm49SAfB47dQf/PY9kykBSTfSheyycUF8xcY3mdHDZOl24+BY/+BAQVO1HkeozeiWWbTqH7xzvVOv1jgGLItCLtSWS3ynZE+Z+pXi2BcpCqWAkXok516teHXVCdb6HZFqkXATBrxa/sWTymarKPuTUZhTltFY1fVV2D6yzUZy9NgTtHRaTZ584oJ401V/7blf0auTZXXmNHMsr2JxmFea4RFY3hQ3fmzc4q/duCjlRvHrZzJ1BsTJ0U+7Do5/cQR3fMd3PFWn6/1r7151tY80h9YyaLqFrmrfdh+Wkdyk6fxr7Nv6LbJ6L+tQ6UkTPimL+zRhsSgv7jd2KFfwoes05TjslD8n5JMb/8YT/nx8IxY/FBNiIbmo6Y/Tfp7MacWKMELyzmPSFGBaIGK1CaP+e7NSdUQ1VYpek5tO8csnjjefLeITFpBAoZJcOMSgKork6C4TlMp0JWREa4Q9b7YMwOowbry/4bv4vj9xkfQ4CY6RfVBBd9o7IaFxkkJ5GB3Fj7OPFwZNom9Ymrdd2eFlieDaM06etWfdvazxCVRC7874DyBRfNVqDMXJaigNJrXAT8d7FArChmRDTy3traCkbRclxm428WafltSp7GCIkMFBoA/jugKN2+GYVLv+F1Tz8cM/VAPhnCltSruQK2x8EF37u6YxVTsNOvtZ565Up/xfl1FCxZjrK4OJQHBqFk2QqUxO5BTWUpKhn1F/x8tFVGGTg5xhpVjRzesfdOfDAqFEcvZDAiV9PROUpEG+Xml2IWZd/VfqdbyMuBuy6xXjCk3+Z/Tr33Z1FUwywEnHT42bVs9jVz2SFrmmbtxahJ5wB8sehgC6Ut6fgDSu9kFKqNsk41ZLzbbNLmFli4ZpUoLquiJH0czv1EvJHU2eiRuLFWikm+TYCQzQg4SbNFXKiiNH7qt0x8+X0S3hpMFmRAMynp/OkdzwQoTQ0/Xqhr/yB4DDQA4ihzUc8IKF6fxuBN6u+btl+glGhRBWd9LefJBDQ0ZgknAaL3X8fbI9mFFlFAOU/bgSIphYfnNvh3HE5GaTtQjhMcS507YomrKw7Yt5565bRjp74DC37foShZtxaV0XGoTD2JyqyHqGR9IFE4KPayTUARZ7dTzUJ/TP7+gJJsG2oaCBhJs6pZW2Qiat/1Fk4fsPOSSnecrXZqdLpe4yjvssAWZmog4zf/mrXiiGJhZ8rXClzSJCRYpiw+1AIo+0/eJVBilPwuTU9JDYtLy5g6S5CrVc5/m/XLxxzRMTE1Vs1EuX46/zuDQxEUdwU5TCFV2sfz5bukbwVFpWqGrbOv1FNPDyTy2Z8JUCS3d+Js08R5cdh//B6ST6dj9g/JSjESA45nwzH/TxqOJkYMieCTaNhcM40mqRfnk9aHXVQAM/VldGkWJeypbCz8+ZhiFK9xu7mw/vDg7z5hY2pnQhq19XLFLuJUovRUUkYOir3KlEWAItfCUfO/Sb2eZBQXzyCmKpvY+Juk+hqFjPxSbOe/7MyCW0ZNWLu8+sSsVrOeyrX27KM4s59CVtnNgj5bycwuFAee6MZL/TJlOsqPH0PVbxdRde0aqtIfoNqSh3rapJrOFHX4lk1AkaK/sRPeb2IUfruZrQprcS5x1DIW5Qd/vWVNjxhYKJsHkFHsJQOgeCEOKhKz2Kv3uGj2lYq4NpL+PMEonAy3Y/qjxAHWPfIcWZM/AOXEfQyezNSLkrsCCq8jlqrn3NUplJmrVD1VTQCnnHnINoAhDrg07tnh68nc4IRv9yH+yA2UV5aTWeRaqlQdVMY1XrX5INdX6tOnB5ZnAxQyRy92gQtKOFekisgqFPLnD8ZYgfItgWJ+ojN/4DYcBCiMQF+wZ5LLfFpqlErWGkr1YsrkIApWsw/v0CcEa7h340JaDvp8Egs3L6ojqh7xZ10Sgn4fRyD28H3m44w4illYTHIY0H2A0Lkwyv8AKATWa2x4jmNB/YhRP6/bv1Gx7CfktGuPEkrAJQRM9hMjKM3Ts3QC4EcnR4LFA4FOzrgvdcpLLgRYS6BYRFEzdUHR+74o/3AQLD2Ho3LFRlSkXaM9WYMxou+MT7MJKI2jPWI7L+53OX+ZEi+dU5xdinBx1PgjN1UqI6mQzINF70tTjCKqn6PqwxhH3/FRMFsYgBoEaC0ZZR4d3U7trTGAYs9azoE/f73icBOjCLi2x98gUOJUb0rSNynON4SdYwvAD2sCL1BQqFZMUcs1C6BsLBMAasMae1gCXAleIkJ09I6AL4GfdOq2CoR1wrQEzINHxU99GvqZAEWi9Q+/nFIXLUCRQ3LPSQtkUpWM8idACY+9bjTRaITxnAXLpuolkqPo9Vt3XbBuWGpZzJvo7BF7L+DkxSz4Racx/86Eg896pbzYk32c+d2Ni/3NTwdZBBJ4vI4qLsJ7o8KsOn/bgSKvLQ4z4oMfcX3sHFQkJMDs5QPLyE9RuHYVct/tgZyXhVX+vP6Q2iPA0QnfEyjrqIBdYVdf+iMy9Nj8OblSyLMGym1vx36NHYr9t6D8/h2UXr6EimOHkZVyCpMXJrcZKCOm78W9BwXsRUgdZyhhVWwgfrP6mJJdpXaRwvvYmXTDOWljCTyGiuSHwdNi6MisD9RgZUtG2Rxx3hh8tc50mfpymrpPGH70O9UElGr2ZxZtPI4BX8SSUfJVMJTm8i9hDIaymYxg3n8iU00319NnKplWTVvCyYF+W/ETC/6EEzcJXD8CksOeStEU1Wszlm04geJiqp4EvbmkjK+15R/AKKTHTexv1BMoopFbyioQxVkurzGRSrmaytTKzCaesVgiMdZjxdYzVEwkJQrgTFYMc1Sj0JPolnT0Nt4extpCFdZUYpT2TyXKOxSXqbfHHb7NyPMbKisque9lF1USoX1RX+S7H8ctopH0q2j51ezq1rJbL2xiFPRudHqPQeF/7KNMizdmmJ7o3ahGGpti3/6wD+lnLrHAXo2ykBBUpRxFyfJVKOw3GBZPn1aBUkgFK8bkiIWUiJezTjnX3lGpW8ZwpHUwUoYjZWJYBiT5cw5Zp/BdT1je8UK+qSNTPBfscPehIiWO4oedVKieHLMfNmOP4dy0qaRCJjqsW/9A/BhwioIHRQ5hFNpWZN477Ip7jYkhOO4bTEO7P2JzspPaFUnFie+hhg9pz283sI+i1sUIYrmcFRNWkLU6ejaDk9UiKRsDsPZ9N6GT93ZEJ99QbCXAymZ/rNenOzFwitFHqbcy0/rQs0yvpFEZiAETotXktWQAsmY37+Zh0NQoBEWmMU2sxb8p1xuytozdhDIT2YyeY3fjxCVOVxCID3NKVNPzuU+9hFHmrzjGD0kNn4txlTnxOx9F0nASmQKwwi+V+n6VUjvqmJYVFFo4/CZNIsNQb3A85eDJB/zQRkf3MQu3qRytkM695LwmyoVSZE5bmAQLO/grtpzBqsCzbIBVsUdwm0N7xpCe2gZLoLxHfT2RQBFqTiXrSGRUag7TA5mQdR8cgt2JvzcchX2kuahqqj8AJRATlyYhO7cEVSU8zv6Girh4lEdGouLgYVSknkLht8tbBwrZ5pidA5Y4dsIiN2ccZcGe3Y41DlOtXNY2uRy5z5ONWgSPRTr3PLI5OZzD352z64ZwN1/M6TITPt2X07FC2LzbjrOs0aTj3vxrztoUNTqv0ifaoZNPgGoWZlGxUimWsAJTm/KKctXD8BgYjKGcLs6XLjojeRVroGlL4hh0pDak07OodifgTl56qCR4WduEQzexbCuBRxVKUh8L1apeY8K4zoHMDtiD4nr3GBZMxy1UokENnX4F1TUTO/BDv0rgtAODoWKUWmzmlITIu7I12rVvGOaxgZxnLlJCTBXZJYEb2w4cvUOFi+lYFPtq1slumZ6Q/prn6EhmFukcN6rE7oTrBrCf9xrFhRfYdeB23Ceya/ghi0oqMfH7GHa1A+AzPgTnrj1S+aeoFZWk+137r+Atzhs19l0kik2Yl4giGl5UEFm4HBb/K/3PwpdNv6FTtmNVSKoSBG5mWNB9xA6sCjivFqyM0unKreeVsTsw2kjUnbKIjs1IVsxCceDnEQqwwlxiYDdGpSFTYxlVC5v8rJKsszniMof9DFGiucFlbGTGyiQGAFn4WtRw12B1ZQVqc/NQERyG4g/6o4gFe2upl2zCuseUapmTOxa5uCHG3gWPmF5Jn0Ues7zMWoc1TiH3pKS3d0GCS28senMi+n24BB69t8CD++btGQR8J+3G99tSGUXTUcHPLHVG869cDoVGx1+nZH4WiSz6JcqWV3OExVrE19VzLoryeXzKPbXbUlQiFzbvfthwnDtRmTLz82UUVMB7bBRce4bCnfXfz4Hn+JkJEr7Xhas5eH/odrwxNAC7Wc9UKSaqxOHUdHQdwEDmyR6Otz8Sj6QTVCLTV3FK4Dqc+/ujy8DN+Mk/laMvZCOCVuTqM5Stfcaxd+K9HnYyZTxgC5nyKqqZFgoTyfNlEkAUscLiEqaKR9XaOXKNTf3CMX3VQZjZ38k2V6Anm6eyy/S5B4pcpD2L6WHTIrlJKRvFJRWoICXmctiwRDRwGrWssgpZuUXYlXhFNZek3hDJVt05hE5sx58nMKLdvFtA2a9cDeIZqVw1KivrYKYYcOFqFnw4qyRjDLNXHkZmbgEqyFTl7EafufIQm3ad5rhGGueXzEi7mYVJHLpzpHEl4qm7nTCHvnSzgGMPhWx0lcNSUmUcnIMyW8x4lFeGIV+23L8v6Vy3kSHIL2ENxShZyYWrPnsRZT+vR9GgUci142gKJ4MLZDxF5GProZqH0nRUvzdhNZWvhZz5CnJ0ZvNS9qHY4dGrrjhj6oYQ1yGY0O1rvMPhRxdVJ8jMmjiFsIMc4VjjdxyFvG4zbSPFdVFhs+vnZ5BZOTOPQksxj0p1Xj57JjLvlc6p6dPXHmPJxhPoyOkEJ9XQYxrH93IdwJpu9RFc53SuNBazGdWPcQRGUqEyMvajvBIORN6meLKDjBGs1Kh3hkaoVDudU8OFxWwYcpo35exd3OdwpUwGyO+3bD+Ptzlc6fV5NNe9TF1PoVw330OmCKTjLmlczOEHSomUz/tv3k/g8t1clBRXKgVTapBifiZRQkvKy3H4/C1sCD9Ntknj5Hcxd4xmYDTn8ezVnNk/gFFUz8TadPyQdcl3647xriIXELnvBnYzSkRwy+/a4NPccxBH5UI+lLFJpzECqP3larZrG3owH527+lf8suMCgmKuIDD6MtYEX2RacBBdhmxXiyvvJWPf01ceIrNw6peNx8Doqwhggb8x/CymUZr+cPTuP9QbspV32tIjmL3iEGb8mIKvOYhnHCmYuSIFM9gXeHt4y5khyb/dfIIQyc8hRXBtiQXVl66i4sBhmL9bhALOcQk7SH0hQ5PCEmamW1JrSNFeIAd/H2Ey4VvXTtyb4oqbHdywz9kT33WZig8+/MlaG/15RFSRkmD1YR4/c2Vys2tuvPY/fp9J1Wk6926MZwd7DPd29PmME8H9RUVsfcLWi3t2Zq+i3TmWEsROun/UJZXejp2boPaLGH0NY3JBbY1m8JGxlIW/cOh012UER13HtsiLWMx9LIOnxLM+Emb2Q+fBEa1fM9dh3HxjqFJqEAkQPhNiub/lOJZwz8kC+tF8jt6sCz7P60lDIMeKgqKuchbvPKZyqvjdERFGv071XZ7uPQCeierVeKHCDgYIOCvESc/OPuF4wydESbfCHvbMfY2dddYNQE9MBqveSdNrsDizbhBSN3ew1juNQDF25cltfLaoLq4aGLSCVd5frsP5ieljqaVkyFEKftm4ZADU2JQkOxzlNV2emC+T93XhMZxMExiegswJs2Du2QtFr78Hs6RcTJtUEU6GuPVaJ6SauiPOuQ+i3LwR6dYf0a79cdTkhUDnzljAYn6exzuY2HUm3v9wLQthuQ4pnluPhkqBEmdQc1iGGvW3h3SphYlYk8m5sjlL3kPy/NbTE27kovM7WAORbOeW2TIZBVKiinquFTBWx5TbLomtXcT2UmjL+bIV2fq44bxGP+ZPD/WYsXdGfZc1VRv1DJGnCQDq81h3MXpS3VS7VI3P1LjmT/tmGc8UKC2244rxmHsaaoTckIE/ezJqSA3QOPLSfFREGlzKIPK4EbUceodzkeUmDr/vrGs0nuTtEoVc6GjGva+s20JlnktNtBrbR1uMo0gTS41jU0GhI8k5ckg6IdclKZqj2iT1e3Q3EYjOvA4ngsWVKtIeF18cc+qCPc79sOGNsZjZdTpGd19Ax9+ALp6/sKbYjDd7boMbr09qNw/m+nJ/Lvfe6/F+9yXoypF5cVy5WYWDuhYDsK05sDCK9CYcuQXYVdQ/6zX/1XcVcNQovbAAr5t5vahTf+VMDjLJy8/pxjTP0XpjDDWEqVI/jsNbA4hhfyurqGsxlDZpDot8K86u7i8m18oi3tjua9j5yUM2pCnbq0BlgNqZ1+suPqBSUAPcch3qNlgKeAQKm4syF9YYNJ9mbdL4Ws8EKM/iQvVrPt3iVNuzbfbUQHnK6oh2wLY54D/FXhooGihPVUb9pzh+W69TA0UDRQPFBh/QQLHBSG2NPvr8Fy/90kDRQNGMYoMPaKDYYCTNEC8eQ7R1TTVQNFA0o9jgAxooNhiprdFHn//iMZAGigaKZhQbfEADxQYjaYZ48RiirWuqgaKBohnFBh/QQLHBSG2NPvr8F4+BNFA0UDSj2OADGig2GEkzxIvHEG1dUw0UDRTNKDb4gAaKDUZqa/TR5794DKSBooGiGcUGH9BAscFImiFePIZo65pqoGigaEaxwQc0UGwwUlujjz7/xWMgDRQNFM0oNviABooNRtIM8eIxRFvXVANFA0Uzig0+oIFig5HaGn30+S8eA2mgaKBoRrHBBzRQbDCSZogXjyHauqYaKBoomlFs8IEmoCxcfxzDpsdjJI/hPEbM0Ie2gfaBRh8QoPw3PNpliHkxV3wAAAAASUVORK5CYII=" alt=""></DIV>

    <DIV id="id_1">
        <P class="p0 ft0">JUST BOOKS CLC &trade;</P>
        <P class="p1 ft1">“Skanda” # 972/1, 13th cross, 16th Main,Banashankari 2nd Stage, </P>
        <P class="p2 ft1"><NOBR>Bangalore – 560070.</NOBR> Phone : <NOBR>+91 080 6570 1480</NOBR></P>
        <P class="p3 ft2">PURCHASE ORDER</P>
        <TABLE cellpadding=0 cellspacing=0 class="t0">
            <TR>
                <TD style="margin-left: -1% "class="tr0 td0"><P class="p4 ft1">PO Number: &nbsp;&nbsp; <?php echo $poid?></P></TD>
                <TD class="tr0 td1"><P class="p4 ft1">Date: <?php echo $date?></P></TD>
            </TR>
        </TABLE>
        <P class="p5 ft1">To : <?php echo $Vname?></P>
        <P class="p6 ft6"><SPAN class="ft4"></SPAN><SPAN class="ft5"><?php echo $vAddress?></SPAN></P>
        <P class="p6 ft6"><SPAN class="ft4"></SPAN><SPAN class="ft5"><?php echo $vCity?></SPAN></P>



    </div>
</DIV>
<br><BR><br>
</DIV>


<DIV class="dclr"></DIV>
<DIV id="id_1">
    {{--<P class="p21 ft0">STRATA RETAIL TECHNOLOGY SERVICES PRIVATE LIMITED</P>--}}
    {{--<P class="p22 ft1">24/1,2ndMain,AshtalakshmiLayout,PuttenahalliMainRoad,J.P.Nagar,6thPhase</P>--}}
    {{--<P class="p23 ft1"><NOBR>Bangalore-560078,</NOBR> Phone : <NOBR>91-80-425-15000</NOBR></P>--}}
    <table>
        <TR>
            <TH>ID</TH>
            <TH>Name</TH>
            <TH>Quantity</TH>
            <TH>Amount/unit</TH>
            <TH>Total </TH>

        </TR>
        <?php foreach($contArrayBat as $brand): ?>
        <TR>
            <TD><?php echo $brand->id; ?></TD>
            <TD><?php echo $brand->name; ?></TD>
            <TD><?php echo $brand->ordered_quantity; ?></TD>
            <TD><?php echo $brand->amount; ?></TD>
            <TD><?php echo $brand->total; ?></TD>



        </TR>
        <?php endforeach ?>

    </table>
    <br><br>
    <p style="font-weight: bold"> Total :<?php echo $total; ?> Rupees</p>
    <br>
    <DIV id="id_1">

        <P class="p8 ft1">Dear Sir/s,</P>
        <P class="p9 ft1">Please supply/execute the following activities as per the terms & conditions mentioned below</P>
        <div style="margin-top: -60px;">
            <P class="p10 ft0">For JUST BOOKS CLC &trade;</P>
            <P class="p11 ft0">Authorized Signatory</P>
            <P class="p12 ft0">Terms & Conditions:</P>
            <P class="p13 ft8"><SPAN class="ft3">1.</SPAN><SPAN class="ft7">Books to be supplied for POs raised against your company name only </SPAN></P>
            <P class="p14 ft10"><SPAN class="ft3">2.</SPAN><SPAN class="ft9">Please indicate in advance about </SPAN><NOBR>miss-match</NOBR> of ISBN, MRP, Discount, etc. to avoid subsequent returns.</P>
            <P class="p15 ft1"><SPAN class="ft3">3.</SPAN><SPAN class="ft11">Please raise a separate invoice against each PO and pack separately by mentioning the PO number both on invoice and cartons.</SPAN></P>
            <P class="p16 ft1"><SPAN class="ft3">4.</SPAN><SPAN class="ft11">Please do not supply "Activity, workbook, Box Set" under any circumstances even its reflecting in PO.</SPAN></P>
            <P class="p17 ft1"><SPAN class="ft3">5.</SPAN><SPAN class="ft11">Any mismatch in ISBN, MRP, PO, Discount, etc will be returned and might get delay in payout.</SPAN></P>

        </div>
    </DIV>

    <P class="p38 ft12">www.justbooksclc.com</P>
    <P class="p39 ft1">Regd. Off. : 28/1, Ground Floor, RNR Complex, Tubarahalli, Varthur Road, Bangalore 560066</P>
</DIV>
{{--<DIV id="id_2">--}}
{{--<P class="p20 ft1">Page No. 2 of 3</P>--}}
{{--</DIV>--}}
</DIV>

</BODY>
</HTML>
