<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01//EN" "http://www.w3.org/TR/html4/strict.dtd">
<HTML>
<HEAD>
    <META http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <META http-equiv="X-UA-Compatible" content="IE=8">
    <STYLE type="text/css">

        body {margin-top: 0px;margin-left: 0px;}

        #page_1 {position:relative; overflow: hidden;margin: 51px 0px 181px 68px;padding: 0px;border: none;width: 748px;}
        #page_1 #id_1 {border:none;margin: 18px 0px 0px 0px;padding: 0px;border:none;width: 748px;overflow: hidden;}
        #page_1 #id_2 {border:none;margin: 1px 0px 0px 3px;padding: 0px;border:none;width: 745px;overflow: hidden;}

        #page_1 #dimg1 {position:absolute;top:0px;left:-10px;z-index:-1;width:666px;height:790px;}
        #page_1 #dimg1 #img1 {width:666px;height:790px;}



        ge_1 #p1dimg1 {position:absolute;top:0px;left:22px;z-index:-1;width:757px;height:930px;}
        #page_1 #p1dimg1 #p1img1 {width:757px;height:930px;}

        #page_2 {position:relative; overflow: hidden;margin: 64px 0px 712px 68px;padding: 0px;border: none;width: 748px;}

        #page_2 #dimg1 {position:absolute;top:245px;left:0px;z-index:-1;width:666px;height:1px;font-size: 1px;line-height:nHeight;}
        #page_2 #dimg1 #img1 {width:666px;height:1px;}




        .dclr {clear:both;float:none;height:1px;margin:0px;padding:0px;overflow:hidden;margin-top: -10%;}

        .ft0{font: bold 25px 'Courier New';line-height: 29px;}
        .ft1{font: bold 13px 'Courier New';line-height: 13px;}
        .ft2{font: 1px 'Calibri';line-height: 1px;}
        .ft3{font: bold 12px 'Courier New';line-height: 12px;}
        .ft4{font: bold 12px 'Courier New';line-height: 13px;}
        .ft5{font: bold 10px 'Courier New';line-height: 12px;}
        .ft6{font: bold 13px 'Courier New';line-height: 14px;}
        .ft7{font: 12px 'Calibri';line-height: 14px;}
        .ft8{font: bold 13px 'Courier New';line-height: 15px;}
        .ft9{font: italic bold 12px 'Courier New';line-height: 16px;}
        .ft10{font: bold 12px 'Courier New';line-height: 16px;}
        .ft11{font: bold 12px 'Courier New';line-height: 15px;}
        .ft12{font: bold 12px 'Courier New';line-height: 14px;}
        .ft13{font: bold 12px 'Courier New';color: #222222;line-height: 12px;}
        .ft14{font: bold 10px 'Courier New';color: #222222;line-height: 12px;}

        .p0{text-align: left;padding-left: 5px;margin-top: 0px;margin-bottom: 0px;}
        .p1{text-align: left;padding-left: 3px;margin-top: 0px;margin-bottom: 0px;white-space: nowrap;}
        .p2{text-align: left;margin-top: 0px;margin-bottom: 0px;white-space: nowrap;}
        .p3{text-align: left;padding-left: 2px;margin-top: 0px;margin-bottom: 0px;white-space: nowrap;}
        .p4{text-align: left;padding-left: 1px;margin-top: 0px;margin-bottom: 0px;white-space: nowrap;}
        .p5{text-align: left;padding-left: 22px;margin-top: 0px;margin-bottom: 0px;white-space: nowrap;}
        .p6{text-align: right;padding-right: 1px;margin-top: 0px;margin-bottom: 0px;white-space: nowrap;}
        .p7{text-align: left;padding-left: 25px;margin-top: 0px;margin-bottom: 0px;white-space: nowrap;}
        .p8{text-align: right;padding-right: 2px;margin-top: 0px;margin-bottom: 0px;white-space: nowrap;}
        .p9{text-align: center;margin-top: 0px;margin-bottom: 0px;white-space: nowrap;}
        .p10{text-align: right;padding-right: 4px;margin-top: 0px;margin-bottom: 0px;white-space: nowrap;}
        .p11{text-align: left;padding-left: 64px;margin-top: 0px;margin-bottom: 0px;white-space: nowrap;}
        .p12{text-align: right;padding-right: 9px;margin-top: 0px;margin-bottom: 0px;white-space: nowrap;}
        .p13{text-align: left;padding-left: 47px;margin-top: 0px;margin-bottom: 0px;white-space: nowrap;}
        .p14{text-align: right;padding-right: 10px;margin-top: 0px;margin-bottom: 0px;white-space: nowrap;}
        .p15{text-align: left;margin-top: 0px;margin-bottom: 0px;}
        .p16{text-align: left;padding-left: 3px;margin-top: 0px;margin-bottom: 0px;}
        .p17{text-align: left;padding-left: 33px;margin-top: 0px;margin-bottom: 0px;}
        .p18{text-align: left;padding-left: 33px;margin-top: 1px;margin-bottom: 0px;}
        .p19{text-align: left;padding-left: 3px;margin-top: 17px;margin-bottom: 0px;}
        .p20{text-align: left;padding-left: 4px;margin-top: 0px;margin-bottom: 0px;white-space: nowrap;}
        .p21{text-align: left;padding-left: 3px;margin-top: 2px;margin-bottom: 0px;}
        .p22{text-align: left;padding-left: 3px;margin-top: 38px;margin-bottom: 0px;}
        .p23{text-align: left;padding-left: 3px;margin-top: 1px;margin-bottom: 0px;}

        .td0{padding: 0px;margin: 0px;width: 44px;vertical-align: bottom;}
        .td1{padding: 0px;margin: 0px;width: 268px;vertical-align: bottom;}
        .td2{padding: 0px;margin: 0px;width: 147px;vertical-align: bottom;}
        .td3{padding: 0px;margin: 0px;width: 207px;vertical-align: bottom;}
        .td4{padding: 0px;margin: 0px;width: 312px;vertical-align: bottom;}
        .td5{padding: 0px;margin: 0px;width: 46px;vertical-align: bottom;}
        .td6{padding: 0px;margin: 0px;width: 98px;vertical-align: bottom;}
        .td7{padding: 0px;margin: 0px;width: 63px;vertical-align: bottom;}
        .td8{padding: 0px;margin: 0px;width: 161px;vertical-align: bottom;}
        .td9{border-bottom: #000000 1px solid;padding: 0px;margin: 0px;width: 44px;vertical-align: bottom;}
        .td10{border-bottom: #000000 1px solid;padding: 0px;margin: 0px;width: 268px;vertical-align: bottom;}
        .td11{border-bottom: #000000 1px solid;padding: 0px;margin: 0px;width: 147px;vertical-align: bottom;}
        .td12{border-bottom: #000000 1px solid;padding: 0px;margin: 0px;width: 46px;vertical-align: bottom;}
        .td13{border-bottom: #000000 1px solid;padding: 0px;margin: 0px;width: 98px;vertical-align: bottom;}
        .td14{border-bottom: #000000 1px solid;padding: 0px;margin: 0px;width: 63px;vertical-align: bottom;}
        .td15{padding: 0px;margin: 0px;width: 50px;vertical-align: bottom;}
        .td16{padding: 0px;margin: 0px;width: 233px;vertical-align: bottom;}

        .tr0{height: 16px;}
        .tr1{height: 17px;}
        .tr2{height: 50px;}
        .tr3{height: 15px;}
        .tr4{height: 34px;}
        .tr5{height: 19px;}
        .tr6{height: 18px;}
        .tr7{height: 12px;}

        .t0{width: 590px;margin-top: 33px;font: 12px 'Calibri';}
        .t1{width: 283px;margin-left: 3px;font: bold 12px 'Courier New';}

    </STYLE>
</HEAD>

<BODY>
<DIV id="page_1">
    <DIV id="p1dimg1">
        <IMG style="margin-left: 47%;width: 223px;" src="data:image/jpg;base64,iVBORw0KGgoAAAANSUhEUgAAASwAAABLCAYAAADK+7ojAAAACXBIWXMAABcSAAAXEgFnn9JSAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAOVtJREFUeNrsXQVcFcv3390bdHe3oKLYYNfDVlTEfnZho/KsJyZ2i51PMRBExcAWFQMFRUCku/MCt7ix+5+5gg/wBiDg8/ff83G9l7u7s7Mz53znnDNnzqAEQSAkkUQSSb8DYWQTkEQSSSRgkUQSSSSRgEUSSSSRgEUSSSSRRAIWSSSRRBIJWCSRRBIJWCSRRBJJJGCRRBJJJJGARRJJJJGARRJJJJFEAhZJJJFEEglYJJFEEglYJJFEEkkkYJH0v07qXC7PcuGiIyjZFCSRgEXSf5IqK/kafL5gKzhCX7/5PGq8W48JZQzm/NZ20+VWrjxLghdJjSaUzIdFUlPQ6VO30ekzho3FccIVRZGO7z/EPiguKqP26995BJvNzQ0KenmDgmEZU6YMGZuYmOk3aIjHE7eJI1g+BxaQDEgSCVgkNT/Nnb+PssN7jpuCAn00lUpxyMkpik9PzyszM9O3V1dX1n77NuZVckpWrp2tmU63bm37sFic/Pgnr1KZp0/q6pUXmI/M1R1hammZ8uHdcR7ZmiQ1CWAt8DiNeSwYNLy8nE0XCoU/rc5XMNmMaXN3v8lNDWCTzf97ka9vCDpwYDtNOTmaG41GHYuiqEViUmYMBUPVjIx0bbjcSk58QkYih13JBqBlaGioY5KXV5ye8/J1eZnvJRXjigJ7JZTQqC5vWYnmrs98+f1FufcLajxGvbi4vFt2doEiMC0pTcFz1UShUAgqFcOHDFn2EnC9UF1Ti2duZcK3szHCbdra4EvmDCFH798dsPRNXBXzMm+wmuqBgBETO3aeNm7yVJeYg3vdcbILfg9isysHAmFfAdjFuqCgJKuykqeqq6tplZVVkAU0J668PJ1qZmZgnp9fnJUZ/jm/7MEDRC4iTNeUKmgvqcxjFSrBASylxVMmj049sP+baQhMyv4Yhj5riXcqL2elsFjc2OLislcDnBefoyD0stzcW3yyt/+7RJV1Ac5jyTUtk7DVEAIxys0qiIXFk13w3yYAIGPAxyEej59ZWsqh6upqmHAreahQIARjHYFqaanpZKVkxpc/fkQkPHmYZEkVtNNFiXa69eAuC6rAEHyoPX8eAbWoqpETfrSMX15VVckSHgYGWiOyMoI2JcSnX9PTH7Zm8NC+xRfPrxaSvf8bAhaKYkRmZn5yRQVb1cLCUF1BQY7W2IfFxCQXp6XlFgN+FFKpFLL1/9ukjuN4EJfLUwfflZlMthmjjMlVUpLnczk85OvTVzlh16/lWjALWhlieF+IPEgDOaMVjW8EPnRzcrLhnZUiuCIQBoPB/FRUzNAxMtTRawi/paRkM9lsLg+Yqjg4iIbwK51GVbC3t5oZHXV5yL79l+fr6Y14MW3uhIo92/4kzcTfCbBMrKxYnbpOG4UiGBg0CaXFC8f1nzPHZbqhoY52/UwJrmDX7osPTpwIfAh6PhcMoIUEiiZ17GpPjmBNTMePBaJl5UwkL68CZbGK0JISAmUyGRijhINCzYWgUBFjfVWhvoUh3r6NDbFg7lCxwljJ43eiUSl3Qd9VMpkcBaFQiAOtivj09E1qxDXfLDtWfvs2KGEjuvgnAmOMKEIIhgYIiitUAxaFgn2ysXMbjCKEGQTNlSsm950/f+wSdTVlNVnlbfM+F33v3usb4KW+gtflgoGRNmSQk+Uff3RzcnZ2HAI0KV1ZZQAN0mDzpnkBr19HLbx42vexppJ85tq1biRo/S4+LEg79/mheVlFaCmHi4WFRNJdXXv09/Z2v1ufB6xYefCy7+UHu1CqfFpXx7ZcW0sTob2DLTFzan+SCRpIQNtZBTQdfT5fSGEwKqL09DTbAC0IBXiCCXEcU1KUt8cwTA38hoF+xYA5h8Lv4FMEK3JyNEU+X8AE5WTl5xe/vhn4/PrLVwkZ/fu1423eMpuoeoYGjUaJ4/EEcnn5xczc3OKyN957E9ukfbE0BeZeU7/T0hLNPTE8uo/7/ImZmzfP+M4Tf285j5aWMLGoqDTqOs9xfYcO7f5QVllz53q/DLrzaouVpcVLwGtCPp+LZuUw0LiETLmywnzNgICd63v37jC/PvWKjU0t7DfAfRNCofkVZN8pJrnvN9GwIK1ZOYGoci5An5PA3HxcyKxZoyKtrIw6SLuvsLCUA8Dqvry6dmJGnC+XbO7GU1RMijaBC5MiwuN4ZWVMNU0tVTNzc0NVHICVsrKCjqKivFJOdqHQ0FBbFfqWdHQ0TPLzS7JrAhaLxUHA+VY8Hl/bwECnnedf0xb8Ob3k/jW/x7tb205N/xrvKwCm+m02u1IITHfGE8+NmT1yv7QdghJt6scpDSd7Gt8GAJZaQmJ6DuSt79qS10zIb1ALF06etutJnz4dEpWUFGxk+C/g/0KnLm2F+w8srukfFaxceZo91m31ikfBhzM6drT1llWvNm0sdFzH9h8eGPg8bPXaUyW7dswjB9jfBbDqUl/nbtyysooY8FUGYDGYAOZy3Eb2IuNsfoJg1LiNlZEz+KSaGOtRBQIhFWhYRWBAKMJoVHkAQFhlJU+goqKkUVBQWqapqapVWlrBABqYUXZ2YT7050AQg2Xl5BTlJadkF1paGhoCkw/X0VZzdZ8/ti9CEEvLylhKAPis3vrdKlA+vNfSGcPNmtv/bU4VmIAPjdTMfEpNwKpJVy6uxkuBRqmEIDaNfc6+fXMJcLCN7abu/fTqSDcA6C6y7nF1HdDuRuBzm5chETHVJitJvyFgdWpriSspK8qMo8IwFI5y5Ub62uTo1AgCpp4Fk8WxzszIC+fxBUoAO7Qh8JiY6HVQVVXS1dFRt+BweZy4r2kJdC5bOfLWvWw6LlCoCL5fQnzTNwgtDNfQAIdIAQF/cwmUkyuk5KUhSIGcloac0LG7fOsRQ3SXLhnvy8zP5V722sJEYj879MFaZqbOhsY3AU8ySEvIUJAGCiiCJsssDPo3CATHaBSJ/JYV58sDbXoZfJUJWHq6msqgbrYpqZmqcPwlOfI3Baxly8cR6em59YpXQQELsTmC/9RLb9h0AU1LzqTk5BRgrHIeqqRKJ/R0NHBjCxPcwtKYcJfgjG5J8lh5Ft28ceL4rMz8VtyycnVOfDxakJIBvlQYfr7/KEWfIjSjowRNE2hBuihhC+/pXH2zjEAUE6rAQfSFmYfkPLmJPHgUiDyocV6xBd9THcNVAJcY4ahQGfzJkMioVIrMEBgUwwRAj+QaGGhIvc7f73nAzFnDZOMfItJKtXAEV2oIYHltuohmZGRTyktL0by8CoxGxxBDI12hqbkRbmxuSCyZN+yn+Gvz9itoRlomlpuVjxUXczElUDstHW2hqakBbtfOhpg77Y/fQkGQJoetLI2IOXN/bKdGeyYoFEr9YqhAl0+Y2Msm5ktKaw67ktqQyGUYmTxq/IbgulHxpQymVUZGXjteJY8CtBCJ5aVn5KVu3OkXE/fxdGVSUra2urqym5wcbczfaye3k5Oj69e8FphHhVwuLwd8xoSHf32Vlp73YfOOq1+HDejM3eA1bSAwuwYDUwxLScl+25SdZmKs25ZGp6myWJzM7o5zzm7evowZ/TkeXfDqnDDj6RHRNfJVR7UY6jVhZJy6mNaDjQ1HI1oLMC3Q/hR0KALzAiFF88yZ4Ow5c8QPFkBbJ2QDFoqDq/ioDLYGYNUQgaZhBCIzBofHE3QCvD0HGiBbNk1zrHueUcZMqyhnxSUkZjzUNRgaoK2pUzJxojPHa0P9wiYA/7kC/htHoWAdNq6bbFf3fEFB6RdgNseFhkZe1dUf+qJzR4eygYM6CVZ5jP9ePtDSB2Rl5SsUF5XLN0QOyxjMsmkztkQGBx9GWtuZtAeyp1iflS+lJRXlM2dti1JQV2ekxl0W+bBhXB+4zxVF0X5bN80wquP6YJeWVqQywHuA4/Ohw34h23deitMzMqkYP6Zv5d/rJhLUFuBJVFlJwd3G2nh5o8wiDtNh+arjtaLiCRxf4NDeepWse7ncytslORlLABBNsLQ09AJMryLpWkVFeei41tHUVHUwNtad0qVLa8TURPfIiJErNq1eM2kw+F30PF1djWZppKwsfhKO4WH3H4V+oOAUhE2gHxRRomtzd45iFTDVVZcZgM11WiivQns6z/IJR0E9ISG9RgBpI4lourBTZgUbmgZcYGlK9MHCyHxwfjOdTu0tbfxXV1M2hwcw54ckxQd4vQuLOT112uZ9QSExReFPd0kb/Gd8K59mCg6JFwG+bAsP21amrsOG9owD5e9ZsGj3zZOXnlUkfjwhMnHoNOpTSwsjBB4NIRiHCd7UC0qjgoJcoK2tWb3vIxDhLiajOAQoFsZA/i6AwxTDxLcTjUZVrH4P6ELs1q0tMnJEr0/de8xecsQnIxoAVnmLpJcB2oP8TzCgYU5OUa16cjhcen1uLSxkGEZ+vHxcXp6+pyZYpaXlll+8eD/u0qX7sU+ffUjncCr54kGkoAuCombAHOnQ3G1UXs6CcUbmuRlFFHNLXZxLoF9azCwTI+GFLbgo3oHGNwcfmqnpuS2V7mh0fS569DgMrnEsBeqdJH/tQbiMCGg9vWvzXSnnwoW7CXPneoecOBEY/vVrWs21kjDCXmOQs+NfkR8vvmxnrtLB3MxN3vdSSN1egDFqIeA4D7QR05onoqOTS4H2ETtv3vbnV648jCouLqu1dM7AQMtuzOi+Zx/c3X+lLDfdtkf3hXJNwJsdi4oYio24z8n/mvd00EbPar5HVRslQjm8fftFIiibLV7p4BmDjxEELtT/KZOwIdSj5+wdoLIhw4f37LNl8/yJQIPRlHY97Gzfy8ERoGMiwJ85xsbatUYghy7Tt1EI4sP6dTMnzZ072rluNPPhI9djvL3PvbgZuNve0FB7eA2zT7Bx06lw0Ej3gDhGwzZFEZTSqpWJ6Z49S5c7Odq3qwO0sMHVQN3VxdUzNTWn4t791ykxMcm5f04dat6zp4OduOsePw7LvnnrxSdrK2OFYcN62NvZmevVvUZHRx06eOmoEEfatbYmhMEofPcZLdE/2mIcNGUt6MswpQq0wLsbfo5KggNRszs8ARbPRGWoYcDE4h4/fiMB8EmspbUV88cyiH8AX0yr+/vDh+9yp03fFAzuew0ekXL7zit4L+XY0b+mjXMdsLDmtYYG2rbbt7kH/5mxcdFKz92vKis5BbO/mcTqQHN7CcDwh7i3TZtPfwH1+gQuegvKj74V9JINPqmvX5/ZDvhrQM1rO3a0HfIm9LR9j55z/tTXH/leiArVUQLvtG7N9EkTJgxykRZIC1cNrFx5MPLN2+gE8GcGUBySpk7b9Bh8ao8Y0dPlxLHVR4HGJy+u3a5efZh2O+hl3JcvKemeq6aq9evXeX0tlD94NWHHzn/ggPyxphzeDNw1v0eP9uNqXisQCqFsG6M4onRgbwDa7IAFKkRo6xnlcMoq7ty79/ZJSUl5gN8172A5ObpY1H/2LDxt9RofH/A1FEXpae062FXs3117kfSU6eOL7t54eNN7+z+vLC2Nlo0Y0cuj5v3e3udPz57tkgxeflHN+85fuBsDwOoijmJ3ejh2yLOwMMah/fDuUyLNxcXz6ZPHPlfbtbPq/q8xK2JrUfBl3Xpu33Eh7NCha9fAC34lUDR37Zrp88DPdhKYvzTgxrMjCIEm79x1UXXlysljly2d+BfQ/Oj/ApaGAmgruhDhYTNnDiKe71/7vuU0LFQkxXVNwpYiY6oADgy6ZSUlilUutGYjAAQzARCMknYNHNjmz98eDpUZwAPhs+eMrmsSXhAHVm/eRBUBsHoAms5PRVnt7R8j+rJsTfUILl+AbNlxNbJVK1N2+3a1XRkQNM6f23Bq/IR1m9b97XMNABYPgOELcWAF+C0OgNUrUP4jGk3++cSpI8qNtNUJDmDiufP2D70VuOW+mprywJr3ABAzDgzYecLVdY074NUwIZX6Zseuq+FOTu0egWf7S/bzbX0XF5cGn/UEFSIJ6hqa7D5/9ODgQgKZOrHXPWC+HahyrX5vs1OnbqXs2HnhA/jzA2CnD2PH9AegN+VVHUDPA2AVD8fxunK4Yv35V34XVseamel71XYq/espaHbAgq7SudOGCT1WjYOMyO7Xf/lroCom6ujQ7cVd/+5d9HvYSB27dk58eMdb7Gh7aOdMAhysvUfusGfP8d6Unxf8HbAyMvJSwcu/+nv9zL/q3nfuXBDUrJ6v8pydvXqFa02RrDzqcyvj/Pk7s3fuXPRR3MhRF6wOHrq2F0Vpz3v26lw2aJCTEABOucQ2QEXO4EIaRTnVc81U4sTpwDhlZcXYRQvHXakzPyGfncUQgeOkIpOIJ3ppv8wkbMncP9DxroXhRkVCDIYPFDXHM06cuo/OnO68VU6Otl6WZrVw0a4QoFk8BwzyrIdjl6y5M/6ddcMJYgyGotPF3btm7dEoIFev5JWU3yYn+VXUPLdu9YTKfgOXr3v8YO9kIOyGNc+ZmOhprFk9bfG8+TvyOZzKvsBiaC+uXoDv3oHyHyMU2svszFu1ZlTXr3TllZWzYBR/Ut17e/XqYDt/wdiVwDz1oqFKMXm5oroFSNOuAFilQqVB10A/MubThbrssAtatrW0sVWHI968+RwBGuoBANOIsS7OjCM+i5bWvA7S1WuPYIBwhiQ5PHQocNPixaNnARPSWOzkC9LCNHJEd34lj58h6TyHy8sH8lM8clBnmWsNVy0ZCRfIsZlMzvdO+hqXlkLgRIm8vNxwMT6pdNA6xXUaSUSLFo8mXoYlJyUkZDyS9sy376ILwEgXBFTYt/M855QEBmwSLJhXjzxK4AqMoCDLlroQX6P/4eza5Xvzw4fYq3X7A8W/BXj27tUBryTQ+Jbok2rH+49+rJbji/Z0ningRjWfIzcb7zMnRByNvgv7+v0noRDvD47D8+YMTZcGVlBDOHf+TvLAPxYGvXoVGUgg6D0MkYu9dWtrzUFTHYDVeUlCHh+fng0qETtm1ACx6ZhCnh7kCwTC2+LOubj0tQFm43IAVu7izr98+Qn6wcAIRsT06t5JrMWupqqUzOcLxPo+ASAOBtZIXwKv0FrueUrUxqAuoWInG1iiOKQyuO63va15Xe0Suim+AzYA9sJRLqueAe3yBWj+OxhCeQPAtASAFS7BVwh7qVSSHC5bNpYQCoWb/h3Ea88OtzhgoQgFYbG4WZLOy9FpHAKj8BYvGVsvcdEzMRICk+17B9KoFDh9yhM3IzhhvDOwhSVPyMyZNkyQkppzU9rz9u27DP0HETb2bQu3rnBptEiv81pYeerMrV1iGkhE/v6bCMA1Ub/S8d6SfqwOdJ4xYGX11PTcRgPWdm/3HrFf/M7/c2n1G2D6QY2XgM5ecCwB/GAiDqTgALR169nPjk4zg9auPRoANBl/HEUf6hmbJh05to5Tx281E+KCuGc/D4mAbsA80IHZhw4ulMhkGIZJ1GxcXQc4STp3P/gNTBwAtB60IPDGZoFk/xxxS+ygpChPnTvXZQywiW3v3wlRkC6jIpCAliZHx0ALrwNW3wH78ZP3WWPGeL4qLCwNAZrDHTll1Y+7D66tqY39MFllbm4gLwpwkzKpAwaLwBrW4C8GLKhpoJJjamB0PEVA1DtPlp2FKQwqFP47M8EuvhGwU6wvycNj0nRgnun99fcFsUKxYP5QIioq+WXN3q/6wKqd7GD0jQBvERP6ZO9PLTdaMHsQEROdHVdUxHhZ42cqjgq+101IoJ9aql/Epd5gtOBMIXS8Q5fO589JjQ7/0tJSUwJHe3l5upO0EBZIMTHJJRcv3v90+vStAJ+j/gfzC0qPgNc9qq9ndKcwNzgjOvxkpdtYR6KOs95DUnmhoZHQlE1XVtEolfZcoOU1KjnhvXuh6ZAFUUyeKe06IAtPJZ0bNbJ3F/DRk8EoMb5y5QkqBbHgf1CmBJR/Q61qgdXhI35fpk71egPaJBgAjF97h/aRmUnXy6dN7FWzzX4A94Xu46z0DbSMERTT+WvtKVS80kItBQNOZhXAC6vlENaLivzmdN1/PVHKqMgEI0g3+Pe1649T+g/oIjZi2sLC0Cwm5trD6/5Px7uN2xrmH7Dhh5Hqzu132VZWhguiPid2jIpOgqMFIzIy4V5efgkeHZUEVdloM1OjJvGzTJoxlJeXV7wfCE9pTk6RhciCQYXfgxSpFCwcIVomx6GSOMd7c/irRo1CVAYMQLhxcQg/Jwcpf/4cEVZUiBzvcIlO7NckOBnT7Ov27O2tNOGxYMHYrjBgEfTDy4iIuMOr15x5sWXbZdTr7yl10dpcnJZWTe/fx8KMDrkODlYy6w6EMVqcU12aTwkqvKBChb16d5LqKgECLnGQgxM7bdtadvnyJeXz7VuhKePH969vFWqBFdBIIwHIQ7v7HgCeh1u2LileUM/VIbq6GvJPHvtMPHzkOvPkqZv7EjKLsm/5rvtBDsFAPu7psw8dnz8Lh8pHPo4hFR4rxxG/PWBB4vME6TUHhwXuOzPGjO4rqdMMFy0cFzpqZP6DO3dC1x71CY5xdestnFuVz3v2kvG8pWuO/4NxWYFAG6OgKL1swvj1h4COde+bfohkTJgyokkWcy+dN4Kwsph0r4LL+ITihAmOEqVmljbf/R+nHKc8W/7unxZpQ3F2TlkzKFilQUEIzdAQ0XBxQWgGBog+k4kU+/oi9KAgeaQA1+XjfKgZlTembDiLlpiUGaegIMf4xgkE0s7e2kRPT1MLCKqppHAaGLAIAzrh0c2xbfz7sC+7dQ2G3+zSs1vF/YCNgipf2ABgWkp8NhAwCCol1tbG9RhhCEZDwlurfErlgPsqblz3ktUrUseZfn07WcZ8SbF+8Sa6XjFVew8uhP6qc9V/b95yJubYsYCvoBJBNCr9YXZWUKkU8/QlkKE+4oBz65b5S4DG1/vylYfbDI1HPe3p2Jk5ZFh34WxgecBrbj389GH9htNRQA5V4BIGTUNjkYfifwKwxLSUsKSkPERTU7WfpEuqGbR7d/tbYGTd6NR9Scy7t0fweX8OIMAB/WDf0+GMmHqA+z4kpBTnMpAePfsLVy0b3WSinJx6VdC756LM+JS0HEVVdSI89Mj3EbS1tSHOeYsmKlQny2thHxakwmaIeC84cQIpvnwZ0ZoyBdFdsOD7EZWesyCXwaRGhH89M2Xarvi42AsNUi+jo5OL7twNvQIYAMaw4aKgdwJOvRNAgUR1evZ06OLpOXV8d6d29pLKgLFRo0f3PaunrzXYxWXVWqduS9LfvT8iBAqoxOBhOIMHHsWHy2b1dWUv9Ad1KW3Ie+XmFEFfGptACV792J8oB89QFXfO2EQPxvvp4jhXQVY5L0JOjAMa256aPr/r15/AWb4Y8Bav581xZUivBxIJ2q2PpPNdu7bpAI6AlSsmvwd9d3TGrK1BZ07dLX8bdlisHP4SH1aL4BX4l5aWe7Vevhtt9dGDBzt9fvJ497v09DynfQcDfxDPu74eREHWbUFR0QtB0O1NTa53vHp9lCjIvSdIj79cS91fuWoCUdmCEe86zeR4N/D0RCzOnhUd8DsEJ3lbW4QVHo4kDBuGsCIiRNfpmRmqdnBotaJzl9axJ44vXaynP1z9/MVn9YZLIBwA4IgiawuLjCnjR2RMnjgyfeTIPgldHDt+1lDTfPHqTdQZl9GeU9as8VlVWcmTarp1d7If/+jR4aup6Unms2fvowDhkwhYefnFQKgIPmC8SgUF2SJF4MTnhrRfdk4hBCwYn1WvoFqBQBgtESS6tIFry1SAXSpVwzpzZl0/OzvzPTV/g477s2f/bg8EgIWjKGvjpumEdPMUPVCf+gLFoduwYT3+iYr0fbNh48SprWwnKe47cENsv/9PAhYKhqKhw1b4fv2a9qq+9ygrK3Q1M9N/O33qgMCz5+4ZL1px4j/RNgIC/dhSzxJnFjaF413ezg5R6txZdFRrVRZnzoiOVvfvi37/wXlMwRYCQ2zgvl0X6r+s5Fv4OuHYtS2+//Bi/ODBRfjZM+uE94N28uPir7ALc4Nz13jOjX74LMbnfvDbhbKKA+DZ7dDhFYfu3n1sIi54uA5VgsdXui8cW59F2o1pVA6FKi+oXzNILr8qA4Uy+KYs6Zp29lYaI0f0FmudODna62/dPG8yRuDtnAeulDVBksZicVbX9wX19bVaQ+B6EeITweex+usZj1Feuv4f9H8esDDQJ507d+H06+c+5ePHuIiG3As1rgnjB0Q6tNZ37dFrKf1XvwuOYeEt9Sx1MetVmiKANHX2bJEmleHhITIHGXfuiLSq6kNsXdRVdKBVnF+U36TZblasdCU+vT9Redb/zcXc3GKZab5dRvUZZGll5AKTJspACTBMos25T4EAE2JNpd1TAaQ12h00f/7YboMHOU2PivliucnrklQN+LJ/6J7MzPzNDdLIDbTsPJZPvH9wr/uBa2evteleQw7FAtaePb7o2g2n0dPnHqG/K2jdv7eZcB03MnvIsOXjDh/2OyFpgbMEbUtr+rRhl1xGdZnates8uV/5HofMBj75lRpWUwWP8nJyRLOB0AwsvX0bYX34IJophCRkMsX5P0SaAIqgzdL+dy+vFdDo1MuyroPrVMeM6efKZsv2+fw+JggqMycG9FfBMB5J57dume9qbmHgcuLkVS1p5cyb4Uzs2HljS0hIxKSKCnZJfasIl+5NmjhozkL3sduTkxIcq+UQq2P7zuLzBaFLlri92bh++ptJ43sfj45O0f5d++XY0YV4R/v2md7bL+wY8MfC5f4BTz/UF7hgg82YPsI7IzNTf/exO78MuC0tTYVsoh7ZNptEwxL/+8+sK6QbGor8Vq1DQ7+bgfCAZiE0D6E5SFH+0TrR09MEAIHKowTRbGm5PNec9q/PdX36dLSp5PHlkP8nBMFq8uQN711Grwri8fhi92IwNzdQ3fD37OkEgtsNdl5DlSWHO7b5+VvbuHZ8HhJxRpb/sCb95fnnMGMj3WHVcojVAKtLVCrlLI1G7SkvL+cEg++ApjHfysrwdUhIpN5/uYFBvSVuAfXwyW5h/6EDspOTc24uWrxnVb/+C9ZfvfboE+wUWeUCodFfv27G5Dt+j2i/6t1MrQ0IHoFmtdTzmtLxDsHK9OBBETCJAyVpBON1gBpAJ9DmW6Dfvo1pvWYhlZUU6HweX7p7gPjZRF710YyaqBxCetKwpOQs5tt30Yn5+SWPXoV+XivpuhEjerXx9Jw6JzIqSmfB8pNSa1cthxMneXlOnuI1KDDweWBJSTlTVlWho3/27FFDQJ3bQTkUARaPJ5gNhH6qhBtamZjoHNbRGyLf2EYm0OZVUEAd29bujtqe4mvnPYUFecG5vfv2eJ2VWXx6+bL98/sNcF9zze/xR1kal7mF4eD4uASNXwVYHovHEHwCjaz5G0VFBTHeulU009YSZmFjHe/QDEwaPx6J6dBB7JE6Z47IpyXOJIyKTmJUGS/NxjweNbJxypBv9OPH+FxJ562tjKETmwr4rl4DG4qifRtSTzs7cxibJsrkUc8BvJekc+/fx8J2BWMgypMsst/iDcHxbtbc/UcLC0vPS7p20SK3ya1sjYfevHJT++/1F6T2FZTD/Nx7DGMLi1dLlhyY3bq124ALF+76ygKuPr07ws1QukI5FDUAn88fL70BsK4YhhouW3GsQU76pKSsYvDmfOjo/Lc1MJnMgTdwKqB6R5iqga4y7MP53hVMzh+gIbou9vh3tu+Gn5cwOzuIMWmKS0RBTvnpZUv3zho0eMmCZ8/CJaZysW1lClAB1Tlz9uEvMwtZBPp9uQWMFG8VHCwCK25806+NVhIzuDT1mkL4DtUmIjQNxWlfVbFHTALDmnN7OPX6XpiRmV8uTQuAgAJdXvv3BaAN4df6kIqyIixfkcCFP63pZ2UVwHkU+C4V0jU50QQCz2WIk7CinPsXi8VJlOTjO3N6vTeBIX3OnPWv6T7qgON4fxaL+0fvvkvpNeXw0J75hEgOJ4+K+HvDuUUAuHq9eRMVIMXSgf5DY4D02pjn2pOYkpLCIKkjJbTfCUInJibxu3oON/CUKWhsDgc8pJa96rFyLFFz7V9dMjHRM0AIvN4dM2jQXyidThNpWCJtiUAqzcz076koKzwGIOt//eptS+/d12vV9eB+dzwt40b5fPcpUQX57CuTJv3t5nf98Slx5QuFOAV0oFoGXIj/i6iApvyhWtCNtmwRLWmBM2/VZhfUtuwjIxFbAGTNoWE1ddYG+A41QYqfm1tr1hCu83v67EMKOJVKx2gVzdWuADjqvTbl4cO3idLOt25tDqPolYqKS+oDRuYNqWeVwCoBzYf+s2U/e/YBLtLOR+vZrlQKhlhaGRQVFZVNkzio25rpe29dsAonhD3btpmmWKV4HMIw7JmSkvzjhPiE0SI53OVXWw4PLMKzMgNFcjhz5u4/b91+OUyyewCGYiBqWEpCNia7Y0WYS2OVckQPvHo1GBUIhDIT82MohsOo8x+AjMVJl3SPpaWhBRh/6Pv3B9RrFDp2bJkmhYKJuD81NYcBFAReKaNCZEKpq6uYtW1r0SkiIlZsXbdsmkbEx/ty+w10zly6ZP9GMPokSRhwqEwG+5dpWPct+xapjHWtgIIOzaesDRu+dSTQTqyuX0fUR478BmzHjzeLD+ubWdh075O7Z4/ogCYhDHeIHzpUBMDVh+ewuW//+efedXDph9atbZozNVe9UiXHx6dXRETEZVVUsCVOfnTp0gZmTVXOLiyVJU/qdVMe18+fBzQsDFFYtua0LD6UGOBalQIHrofNU9fSaZDmesM/NAzcv03S+blzRzsNHuw0qqi4wHD79ssoQfyr0Iwe3RduztEqIuKrVDm8eiXsAZDdMz8M2KKVBAjceI6G5RcUSQQe6JiG6X2vXXsUBl6Sq6SpKGLb3Fw2IpQdSAdXsKdBBa3u72lpuRIjfa2tTVpBLTghMbNehqGRkfaY6u/JKVnFQMOqqNmj41wH9EmOz5KqsfldWUl07tO9qKyM+bLuucTEDCirAmUNxV+2ddJ1/437zbw2iLIP5O3ejSgAc9AaAFW1OQW1kqQJE0Tr9JrEj9XMqWbgshx4wBAH6OeqS+3pPCignzEqNf7xk72CKr+Mg6xyHRxs1EEnUeoZrmQuLmuoOLp8ORj6cwqBwJ6RdI19W0tNMLJp5KTmyRrI+zWmzcaM6WeNEohy2HOZGYckln/x0n34HnDhfqZz77YNWg+7YtU4YtzYDd7l5SyJcY3bts4f26qVaZ+z5+4o1XR7Dh7kZAPUHv2sVBly6OdJKCjIX6v7+7eVBKKlVgJM2tTG23fR2VP+3Ljn6LGAXSiCJffr2UnkoK6oqIABlo4yAev15zgCw35IZjZz/q4wSdOl+vpael4bZo95/PidzLiXEyfvoxQqZWb13x8+fE0B2lkhzPBZ/dvQId1H5uRnyfRV3Pf3EqipK/+QWDA+ISMfmLUVJqYGvwKr1IHZchuo1ku+j7bu7iKTCi4chqZUtpfXd/NQFEF+9qwIzODRlI4dVgukminBMe4TjkLGm0o5aH8TRgY6vBqOaplbtagoK8oBrFUsKCjBZLcrcrs+dYLO/zdvo2Hix3jnwct8Kit5eeKu69u3E9wkwSg6JlkW30rU6mbM3CIRDAAfWwHeNkhMiac3pvyqHPVxoCUh4iX4HFtRryDXmt62j5HnuG/fxQ4XCnGxTnIzMwM1b2/3NRVMRgfQTt+TA/bq1UEfFGOenpmjJut58nI0oRgNFz6PDeUQMzU3EhYWlsaIVYXj0iOBSXdjjNvw9/l590s3eE0VcW1CfCZFWUmhlbQHvwuLycvMKoizbWX9g0rfsb0tO/ZrqsS8QG7jBi537NbK3nP9Ganq73i3Xs50GrVHtTZ48mTgc4DDRUDA8X9NTCPTXdsXuU2eskOmCauspGhUV8O8evVROIJixXNnN35zVWDja/yQOrF+PpbNQFBr5R+HQAU1KmhSQRMQOt+h78raz08EWDCuCWZDyAWaWKMBS4zjvaiZQCqJTysNYismrizRfOJWoHtue5maTzyfdoVA0WRTC3PBN38p0Z9Go7aVVZahkY4SaGOl4gq2NMDqB3Omg1dsX5/6eW04GQtxC0WxpEHOA1g5OUV/ibvOwsJQxc1tYA+C4OmdOROMShkLxAKKv//TrODgN/Hh4V/FZrx1dnY0tzA3aI9RMA0v76uoFO1KLLDv2HEBztAAwCJCraysCqq0VrGziUqK8jTRrCeB0IR1gvcHD+qaDyyROZLaC8asbfh71pr8/BK1mibtpo1zhyEEbqOnP0pWPNsPPjjfSw+gGp4P5RDr1MlWCMyvG+LunDJlSF8MpbJPHFlSK17F5+hyT5iSQ9pTDx68+gageezI4T1/UD1dRvTjB91+eYjL5fEkOBn1Dx9eGWBrqeM4feYesUDDZHHc1NSUv9c7MPB5PAEZC6P8oNG5ju2/WUdX3vbPKXskAmBlJV9DRUVxUi1T7PqTlJycwo9aWtoyI3RBe0jc2KBNGwv9zl3s9PgIs0Hzn6BOOuJ+h2ENMBgTalowxgmCWLXzGgJZwtChInOrKR3vTeXDyhZSKp5y5VO3MtSfDszTPzy/WGvHoTLVLZ8q6TsBkBzECOppOZrWU0vr1jmB1zcK4KYRAFxu1ads5z+6Gf9z3mt2p/YW5qPHbaB6LPfBPJb5YHCTUxi6U5US+DkYBOoFVps2n44FVgbML/XUeaRzse+lVcT8Zad9CwsZYqf5PVdN7QcGJof9h/0UJAxAh8Q1L/QtLV6yFz7n9bDhHjPE+crgTOTmTfOmAga2v3D+prIEMDwoAQwzr1x9GAlz1BMUevzb10crpZmOYJBXdmhvYwLaXfPT5/Qf4uA0NVX9GAzmaUn3L1k8friSksKYmr9Nnz7cYeTI3m4IwrPs1d9Dmpa4vK6G+y4sOh98/QLlEIXJ/HT1hxp//uQbIW7bHzCiXOLzhR5mZnowQZk6UAdhgvh90jp6m/e5T0eOXPcFKtw/+bnBxWIdiQZDNXZuX+gza+bIydLKAp33GIwEHwAgCKtMA+i0HF0zmRpcQuDUfdZpYN4ewwh6ekLytbcAfLrU8sGUMVO/fk2buXdv4KuAAK+6AYM/bKsEmah7j9lXwRNPTprs8ung/gWSggw7iNOExPjtIoDGtmXWzL1334UdrVfAIrDdF+nrafnIuq48JESUU+pnQOoHJ6vwR4QaSkEbvI09ACjmVx695DOPXvC2Ui6zFMcg88FJlxRClKMcycGESDlOp3OdB/TmX77k6QAFG/AZJi2eqDkJata79/gmHD8eEA3qeAtFqPfy8+5W/KsxT5YLDt5zFwj2H3XvjY5OTjxw8MrEMjYt8sbVNTX7+QJSIxd6TT4bOWpVWFFR6RcCQS/QqZSoGTOGWy5fPum5trb6Dzue3rv3+tmsWVs9bNq2+xL6bI+wBlhBUP8hvgvuUjNt+iY4y/yYIFC/pKRAvqqKggvEY0naGKTMzPzSx0/en1m72mfXyBHOJWfOrarFEFlZhVrq6srvlJUVrOvbrnAWf+/eyweP+Fw/2mfggIyAK38RYgB3es1+6NJ1xpviYkZ8tRyKAMum7VQFfW0lt8uXNh8yNdVX/5nO3rYNgJXPdTi/fq9rty7v7wZtExtRPnTcFmpE6JuuXhtmr1u8yG1EY58HwWrkqJVPCwpL/VSV1O44dGnLOXVsWYCWltoYcdeXMipuKMjLPaDTqclV+w3CkWZGzfxBENUnT97wGpQZRKXJBeRk3i6RYK55NabOQLN8Z9F68sDc1ACpM2B377w2GDGyZ464c3C2kHH7tsh5Lc5x/bP0BCd+SODXHUMRQxlzVFwCFXzk0QujefTiRxyFTAaOQfMD+n3gTin5wC7OAwNLDkKXL7V3sGP36OHA37p+0r+70gDzD25O+qsmOGDfL16851N8fDqsLxB0NGjRgilZGzdN/V7Ha1dfoss8dulcvbL5zIABXUbWLYPHF3AqubxQCoUSDvjMBAzwfcTNDMJtwebO2x5RVMSA+x8+VVFSeZac7F/h5rqFilC5jt5bF5xo1cr0h9xd5eWsUj5fEAK0rq9ycrR2GIb1Eae5nTkblLZ+/TFo0kLtyq8g78HnRgL4e3PL0SPN29qXvH+697s8h4V96evo2DakoeXl5BbF83kCPw1N1VBlJXkBqD8E2hk1ARTK9fLlB74C7SoH1D24Wg5F6l7iF1+Ont7wBxMmrvfy3ua+AnSCeUMrAXejPXLE79OtoJc3AFO+0NPXT5EEVpCCA7wEDu1nRG7Zehbau6mTJg6aCEwnnYaMgsBkS91/4MpbmAQfRSjPduxcxn4b+gkFppTEXXk01FVcoZUo7hzcjfbEicAEn6MBHwiECEcR7P6q5TPEJlsrK2fJq6spN0oogJlpKGQzO8xZsC/szImVEp2fDx99zO/br2My0Bat6p6DsVjqLi4ik7DaHIRR5XCBcVOQEvLjzCCMeDeUsGoBaFBF0GF+n6MAVzTDfNzZooMgUhECzVPS1C63a2PFs7e3Eu7eMk2KhglxoeUiSCAfJSdnVzx9+r7g5q0XmXFxaVD7iwTV+IwiaLzHspmFa9bVjoifOKkPwWKxCidN3jhn6pRBsxe4j11kY23yXRui06gK4HCGVqokBzj0KQEzLRYUHAbe9rWysnJ8cpK/qPP8b3gJRo9eH9a79/whu/csWTRqZK/FGhqq33PUw52jwceYqkMs6HptOPkFmLNwq65ooFnd09UxaHSUcXZ2gTGo45S0LzHXq/pVRM+eRr0EA/fCjh1bHZC0z6hYX6OBNlyi4SVhMOddvfYoY+9e3+SiorJM0D615BCtzu9+5uwDdP36I1oEIuzZpbPdgIXu45zNzQ10AYNJXI0NA/wSEjLKQMPHv3oV+VG02y1Ke9+nR7cS/xsb6mX2DB60jvIxOlIHI3BHGMcxeJBTNwcHGwNgA9OhI7MuY+XlFbHfv4/Nu+7/JDIvrzgMVD+KRqUnbtm8uHT2nEHEpi0XUDab2UpZUX6utbWJs6WVkS5cCwbKo9Usr1rtBSanICLia1E0eJd//rkHc0/BUSiKQpVLWeUxo2TFyjFivTd+1590jvwUPw9obGbVm1Qg0pYg1ZhlAyNk2dOn4SeGDO0bcvHCWqmzNbGxqZ4AyKV60LkJCaIMCIygoCYDrFgc7hBb+zcYo9UHQ2tpUw85Cml32IrxqQJqMhByOHnzBbRHury8XHnHDvbcAf07C5Z5uNbbAwYYViMw8PmED+GxvUGfa1dtZtt0VLWvSHJyVikYZIuRbxl0mARMLUwAoEWRZBpVLt2pV5eKG9c2SO0b/+uh6Oq/fZSZFWXGg50d+zv/0W1s69bmdjo6GipwcXDNgRAMypzw8K/Ft4NeZgHNKgs8Lxnu4Utg1I9dnRxL7gX++Kxjx4LRI8evKhQXFdiOGzvArV/fTs5AHs3gLuEwzXANd0N5bl4R533Yl5LAmyEZVXsKwsSPMQRKiR83enD+seNL8c9RSaPv3X3lmJ1T2EYgECrI5Nmq9iopKee9fPkJyDd6tiAvOL327OVqKkbjD5g8cdAK8KcR0PxE/ik48SXa8Qb8Z2iorainqwlHdxTm0a95f3FxGQu0D4wPKw99/bno4sX7mSIHuwQ5/A5Y1dSuy1y5/KwsTTirDP6E9qmJkaGOYd8+HQ2Buo59E9bH0PcAndswahYGQueColKsrC0K34Yea1S+c6eeC+VSklOghmUGNDQ9AkU00W92rULVkAtDKljEtyUFEOUz5BUUswf+0Yt1/vSKWuBoaT2FxmKWaAMtCarhuui3TWFgg8HGhDE+lKqhvLLqPeBShWzwQ4aKinpe394O7HPn1koFXNvO8+RKsjNMMAJRaeiqV/BuQpxCydm6zaPYfdYfUu+2tZuqFBF+Oh2mvBEHUhXPnzeLSQg79SVeu2owiGYUBRUBFTD3Un2Zym+Kcew9YOp4wJnpGhrauS4uvTm7d83/qZ0ztA1HqGOEUB/FCYVmWVEMBIlAUS74nwcEiosKhJVyqqq8th3bcAf36ShYvmxMg57q5X0FvXvrOT0rM0sHlGkB+M0Y9DHEd6ioUqt4jQ3+K0XhhCsB5QXLbNehTcmTh3tlZg9Z5nkCvRXwRIXLYRqCMmCIgC7xja9Vq8rHReMHKB8q8ECoU6k0+Ryn7p1YN/w3CuvwrC6QLw1wUBrEsxjCoalppmfHX+HUPdfeYbZ8Xn6OPrgKyq6aCFdQKK9oJWhq6A2F4VMq0ImPfNsGk1712WA5/AGwqsnOejylmM1URHFcFT4MdDKtepcdcAcPfOeAWysICoVDQeW5edk3BE3BS3qmblScx6QDZpUDLygPnkv/xmIILB8u2qxEqDSuU+dOPFnpivVMxlEQHgtO0coR38qhAjWfJmp++Bo4TOgJGguUiWOUyiED+/HhTFB969pn4F9oRnw2igsblreNpkQnkpMu1us5M2ftxgb0t3f/889hPlDLZN66iTF8L2HNAVK1TE5wBIlxvKvyFbNOlKvEMHAM7nIcIjKfEKyku2NP3q2g9U0GL47d3dHcjAoUwQVN/m5KanTCvp014u/v1eRwaKA/mipAKxUwCLYwlxdKVMc6Qt5lg98rVbV1+Amxlxqc7G/U8LVoWNgnKk7F6KBhoMDLo1VCDwYMoCgQHKBRcbp3as8LurdD7LuNn7IHjQiLRvgsHtoQhDe01CXevT4ksb269/JEk5O/UDEcw8BwjMIUgTjOxzEBQuAUGKNOpaFCIR3iCPFNDumNkUOJgFVNm7dfQTNTMrGyUg7Arm/MQ6XTECMTbdymlRnhPm9Es0UU7t1zBc3OZqAAvBA1LQVCSU0dWbV8bKOe5+MTiPIqcaSwuBipZPLBCIAhegbKhIaWGjJ/rssvi2KvD+kYjtB1dem16ubNEJ2z2kVDzKkC/Ybcn8inMdgEyk8TUKF2SiTxaWVMAhVFD6NwdK42C2CeC4A+rWh8DSWUoFPk2JZADfk+EmdXKqbfLleD25GHgT9DFOQU42bMGFOxefOf/+n2+xXkc+w2WlKch5QWCVEKEF59I01k1YoJTdZOx0/eRXOy8xAWg4viFCpibKhKrPKc/J/vh1Mnb6JMFpDDoqJGyaFMwCLp19Nyz7PYlYv+cIJO/5ROkbsVVTCr5nkYIV4ipHAgILEIlJcsoJYwwW8vuPLZVT6aiqqDKfLXAM0YjHQskZYMDrS2y1u0bq3KnFGzk+f0saYKrGIr5QpS+HQYHxQOIO7R6NFD80+eWiYke4ekliQSsH4jWuJxEO33xM8ulE39M0FAbR1eKVdYZb1VVgES9GEwqj6/gROClgMNFXziHATD+Opq6nwDfXWhjo6eUE1dnlBRViWwKl8VXIbB5rLQosIKNK+0nFKYnUdjlJVrAXCDkakYGA5LMDotd+fWZeXTZwwkGYckErBIkk4r119AL57z0wcdp42Ktn4CgCVKxkZwaVT5SgsrI56psb5QV08TN9DVIFav+XkzYeP2S6hQiCMWRobI7FnOJMOQRAIWSQ0j+84z0dZWtoihPg05dHgl2YkkkYBFEkkkkfRfIoxsApJIIokELJJIIokkErBIIokkErBIIokkkkjAIokkkkgiAYskkkgiAYskkkgiiQQskkgiiSQSsEgiiaT/H/R/AgwA7o+QQauKQRAAAAAASUVORK5CYII=" alt=""></DIV>
  </DIV>


    <DIV class="dclr"></DIV>
    <DIV id="id_1">
        <P class="p0 ft0">Invoice</P>
        <TABLE cellpadding=0 cellspacing=0 class="t0" style="width:590px">
            <TR>
                <TD class="tr0 td0"><P class="p1 ft1">To,</P></TD>
                <TD class="tr0 td1"><P class="p2 ft2">&nbsp;</P></TD>
                <TD class="tr0 td2"><P class="p2 ft2">&nbsp;</P></TD>
                <TD colspan=3 class="tr0 td3"><P class="p2 ft3"><NOBR>Invoice :#JBSPL/2016-17/82</NOBR></P></TD>
            </TR>
            <TR>
                <TD colspan=2 class="tr0 td4"><P class="p1 ft1"><?php echo $branch_name?></P></TD>
                <TD class="tr0 td2"><P class="p2 ft2">&nbsp;</P></TD>
                <TD class="tr0 td5"><P class="p2 ft4">Date</P></TD>
                <TD class="tr0 td6"><P class="p3 ft4">: <?php echo $date?></P></TD>
                <TD class="tr0 td7"><P class="p2 ft2">&nbsp;</P></TD>
            </TR>
            <TR>
                <TD colspan=2 class="tr1 td4"><P class="p1 ft3"><?php echo $myArray[0]?>,</P></TD>
                <TD class="tr1 td2"><P class="p2 ft2">&nbsp;</P></TD>
                <TD class="tr1 td5"><P class="p2 ft3">PAN</P></TD>
                <TD class="tr1 td6"><P class="p3 ft3">: AADCJ8009L</P></TD>
                <TD class="tr1 td7"><P class="p2 ft2">&nbsp;</P></TD>
            </TR>
            <TR>
                <TD colspan=2 class="tr0 td4"><P class="p1 ft3"></P></TD>
                <TD class="tr0 td2"><P class="p2 ft2">&nbsp;</P></TD>
                <TD class="tr0 td5"><P class="p2 ft3">TIN</P></TD>
                <TD class="tr0 td6"><P class="p3 ft3">:</P></TD>
                <TD class="tr0 td7"><P class="p2 ft2">&nbsp;</P></TD>
            </TR>
            <TR>
                <TD colspan=2 class="tr0 td4"><P class="p1 ft4"></P></TD>
                <TD class="tr0 td2"><P class="p2 ft2">&nbsp;</P></TD>
                <TD colspan=3 class="tr0 td3"><P class="p2 ft4">ST No. : AADCJ8009LSD001</P></TD>
            </TR>
            <TR>
                <TD colspan=2 class="tr1 td4"><P class="p1 ft3"></P></TD>
                <TD class="tr1 td2"><P class="p2 ft2">&nbsp;</P></TD>
                <TD class="tr1 td5"><P class="p2 ft3">CIN</P></TD>
                <TD colspan=2 class="tr1 td8"><P class="p3 ft5">: U74999KA2016PTC096776</P></TD>
            </TR>
            <TR>
                <TD class="tr2 td9"><P class="p1 ft6">Sl.</P></TD>
                <TD class="tr2 td10"><P class="p4 ft6">Description</P></TD>
                <TD class="tr2 td11"><P class="p5 ft6">ISBN/Book No.</P></TD>
                <TD class="tr2 td12"><P class="p6 ft6">Rate</P></TD>
                <TD class="tr2 td13"><P class="p7 ft6">Qty</P></TD>
                <TD class="tr2 td14"><P class="p8 ft6">Amount</P></TD>
            </TR>
            <?php $i=0;?>
            <?php foreach($array as $brand): ?>

            <TR>
                <TD class="tr3 td0"><P class="p9 ft6"><?php echo $i ++; ?></P></TD>
                <TD class="tr3 td1"><P class="p2 ft7"><?php echo $brand->title; ?></P></TD>
                <TD class="tr3 td2"><P class="p10 ft7"><?php echo $brand->isbn; ?></P></TD>
                <TD class="tr3 td5"><P class="p6 ft7"><?php echo $brand->price; ?></P></TD>
                <TD class="tr3 td6"><P class="p11 ft7"><?php echo $brand->quantity; ?></P></TD>
                <TD class="tr3 td7"><P class="p8 ft7"><?php echo $brand->total; ?></P></TD>
            </TR>
            <?php endforeach ?>
            <TR>
                <TD class="tr4 td0"><P class="p2 ft2">&nbsp;</P></TD>
                <TD class="tr4 td1"><P class="p2 ft2">&nbsp;</P></TD>
                <TD class="tr4 td2"><P class="p5 ft3">Gross Amount</P></TD>
                <TD class="tr4 td5"><P class="p2 ft2">&nbsp;</P></TD>
                <TD class="tr4 td6"><P class="p2 ft2">&nbsp;</P></TD>
                <TD class="tr4 td7"><P class="p12 ft3"><?php echo $sumres1?></P></TD>
            </TR>
            <TR>
                <TD class="tr5 td0"><P class="p2 ft2">&nbsp;</P></TD>
                <TD class="tr5 td1"><P class="p2 ft2">&nbsp;</P></TD>
                <TD class="tr5 td2"><P class="p5 ft3">Less:35% Discount</P></TD>
                <TD class="tr5 td5"><P class="p2 ft2">&nbsp;</P></TD>
                <TD class="tr5 td6"><P class="p2 ft2">&nbsp;</P></TD>
                <TD class="tr5 td7"><P class="p12 ft3"><?php echo $discounted?></P></TD>
            </TR>
            <TR>
                <TD class="tr6 td0"><P class="p2 ft2">&nbsp;</P></TD>
                <TD class="tr6 td1"><P class="p2 ft2">&nbsp;</P></TD>
                <TD class="tr6 td2"><P class="p2 ft2">&nbsp;</P></TD>
                <TD class="tr6 td5"><P class="p2 ft2">&nbsp;</P></TD>
                <TD class="tr6 td6"><P class="p2 ft2">&nbsp;</P></TD>
                <TD class="tr6 td7"><P class="p12 ft3"><?php echo $final?></P></TD>
            </TR>
            <TR>
                <TD class="tr4 td0"><P class="p2 ft2">&nbsp;</P></TD>
                <TD class="tr4 td1"><P class="p2 ft2">&nbsp;</P></TD>
                <TD class="tr4 td2"><P class="p5 ft3">Processing Cost</P></TD>
                <TD class="tr4 td5"><P class="p2 ft2">&nbsp;</P></TD>
                <TD class="tr4 td6"><P class="p2 ft2">&nbsp;</P><?php echo $totalQuantity?></TD>
                <TD class="tr4 td7"><P class="p12 ft3"><?php echo $processing?></P></TD>
            </TR>
            <TR>
                <TD class="tr6 td9"><P class="p2 ft2">&nbsp;</P></TD>
                <TD class="tr6 td10"><P class="p2 ft2">&nbsp;</P></TD>
                <TD class="tr6 td11"><P class="p2 ft2">&nbsp;</P></TD>
                <TD class="tr6 td12"><P class="p2 ft2">&nbsp;</P></TD>
                <TD class="tr6 td13"><P class="p2 ft2">&nbsp;</P></TD>
                <TD class="tr6 td14"><P class="p2 ft2">&nbsp;</P></TD>
            </TR>
            <TR>
                <TD class="tr6 td0"><P class="p1 ft8">Total</P></TD>
                <TD class="tr6 td1"><P class="p2 ft2">&nbsp;</P></TD>
                <TD class="tr6 td2"><P class="p2 ft2">&nbsp;</P></TD>
                <TD class="tr6 td5"><P class="p2 ft2">&nbsp;</P></TD>
                <TD class="tr6 td6"><P class="p13 ft8"></P></TD>
                <TD class="tr6 td7"><P class="p14 ft8"><?php echo $finalProce?></P></TD>
            </TR>
        </TABLE>
    </DIV>
    <DIV id="id_2">
        <P class="p15 ft9">In Words: <?php echo $inWords?> </P>
        <P class="p15 ft10">E.&.O.E.</P>
    </DIV>
</DIV>
<DIV id="page_2">
    {{--<DIV id="dimg1">--}}
        {{--<IMG src="Wakad%20JB%20INV%2082_images/Wakad%20JB%20INV%20822x1.jpg" id="img1">--}}
    {{--</DIV>--}}


    <P class="p16 ft11">Terms and Conditions:</P>
    <P class="p17 ft12">1 Payment : Within 5 days from the date of the Invoice.</P>
    <P class="p18 ft10">2 Late Payment : Interest at 18% P.A will be charged for late payment</P>
    <P class="p19 ft10">For NEFT:</P>
    <TABLE cellpadding=0 cellspacing=0 class="t1">
        <TR>
            <TD class="tr7 td15"><P class="p2 ft13">Company</P></TD>
            <TD class="tr7 td16"><P class="p20 ft14">Name : JUSTBOOKS SOLUTIONS PVT LTD</P></TD>
        </TR>
        <TR>
            <TD class="tr0 td15"><P class="p2 ft3">A/c no.</P></TD>
            <TD class="tr0 td16"><P class="p20 ft3">: 50200021884772</P></TD>
        </TR>
        <TR>
            <TD class="tr1 td15"><P class="p2 ft3">Bank</P></TD>
            <TD class="tr1 td16"><P class="p20 ft3">: HDFC BANK LIMITED</P></TD>
        </TR>
        <TR>
            <TD class="tr6 td15"><P class="p2 ft12">Branch</P></TD>
            <TD class="tr6 td16"><P class="p20 ft12">: JP Nagar II Phase</P></TD>
        </TR>
    </TABLE>
    <P class="p21 ft10">IFSC Code: HDFC0000133</P>
    <P class="p19 ft10">For JUSTBOOKS SOLUTIONS PVT LTD</P>
    <P class="p22 ft10">Authorised Signatory</P>
    <P class="p23 ft10">JUSTBOOKS SOLUTIONS PVT LTD, Skanda,# 972/1, 13th cross, 16th Main</P>
    <P class="p16 ft10">BSK 2nd Stage, Bangalore <NOBR>-560070.</NOBR> Land mark :- Near BSK 2nd Stage Post office.</P>
</DIV>
</BODY>
</HTML>
