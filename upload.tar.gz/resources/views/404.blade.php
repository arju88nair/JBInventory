<!DOCTYPE html>
<html lang="en">
<head>
    <title>404 ERROR</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
</head>
<body>
<div>
    <img class="img-responsive" src='{{ asset('img/404.png') }}' alt="Chania">
    <span style="top: 50%;position: absolute;/*! z-index: 1; */float: right;margin-left: 60%;font-size: 3em;color: brown;font-weight: bold;">You Found Our 404 Error Page</span>
    <p style="font-size: 1.4em;font-weight: bold;color: darkolivegreen;">Jokes Aside,This is not page you are looking for ! The page does not exist ! If you think this page should exist, we might be working on it! So take a break and treat yourselves </p></div>



</body>
<style>html, body {
        height: 100%;
        width: 100%;
    }

  </style>
</html>
